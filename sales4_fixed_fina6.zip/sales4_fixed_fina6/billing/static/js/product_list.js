  document.getElementById('viewProductModal').addEventListener('show.bs.modal', function(event) {
    const btn = event.relatedTarget;

    document.getElementById('vp-name').textContent = btn.dataset.name;
    document.getElementById('vp-fullname').textContent = btn.dataset.name;
    document.getElementById('vp-photo').src = btn.dataset.photo;
    document.getElementById('vp-photo').alt = btn.dataset.name;
    document.getElementById('vp-brand').textContent = btn.dataset.brand;
    document.getElementById('vp-group').textContent = btn.dataset.group;
    document.getElementById('vp-price').textContent = btn.dataset.price;
    document.getElementById('vp-stock').textContent = btn.dataset.stock;
    document.getElementById('vp-balance').textContent = btn.dataset.balance;
    document.getElementById('vp-description').textContent = btn.dataset.description;
    document.getElementById('vp-edit-link').href = btn.dataset.editUrl;

    const suppliersBox = document.getElementById('vp-suppliers');
    suppliersBox.innerHTML = '';
    const suppliers = btn.dataset.suppliers ? btn.dataset.suppliers.split('||') : [];
    if (suppliers.length === 0) {
      suppliersBox.innerHTML = '<span class="text-muted">Ninguno</span>';
    } else {
      suppliers.forEach(function(s) {
        const badge = document.createElement('span');
        badge.className = 'badge bg-info me-1';
        badge.textContent = s;
        suppliersBox.appendChild(badge);
      });
    }

    const statusBox = document.getElementById('vp-status');
    if (btn.dataset.active === '1') {
      statusBox.innerHTML = '<span class="badge bg-success">Activo</span>';
    } else {
      statusBox.innerHTML = '<span class="badge bg-secondary">Inactivo</span>';
    }
  });
