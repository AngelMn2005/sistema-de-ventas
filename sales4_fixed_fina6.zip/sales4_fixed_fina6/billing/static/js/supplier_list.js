  document.getElementById('viewSupplierModal').addEventListener('show.bs.modal', function(event) {
    const btn = event.relatedTarget;
    document.getElementById('vs-name').textContent = btn.dataset.name;
    document.getElementById('vs-contact').textContent = btn.dataset.contact;
    document.getElementById('vs-email').textContent = btn.dataset.email;
    document.getElementById('vs-phone').textContent = btn.dataset.phone;
    document.getElementById('vs-address').textContent = btn.dataset.address;
    document.getElementById('vs-active').textContent = btn.dataset.active;
    document.getElementById('vs-created').textContent = btn.dataset.created;
  });
