(function() {
  Chart.defaults.font.family = "'Inter', sans-serif";

  const topCtx = document.getElementById('topProductsChart');
  if (topCtx) {
    const topLabelsEl = document.getElementById('top-products-labels');
    const topDataEl = document.getElementById('top-products-data');
    const topLabels = topLabelsEl ? JSON.parse(topLabelsEl.textContent) : [];
    const topData = topDataEl ? JSON.parse(topDataEl.textContent) : [];
    new Chart(topCtx, {
      type: 'bar',
      data: {
        labels: topLabels.length ? topLabels : ['Sin ventas aún'],
        datasets: [{
          label: 'Unidades vendidas',
          data: topData.length ? topData : [0],
          backgroundColor: ['#2563eb','#16a34a','#d97706','#7c3aed','#0ea5e9'],
          borderRadius: 6,
          maxBarThickness: 26,
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, grid: { color: '#f0f1f4' } },
          y: { grid: { display: false } }
        }
      }
    });
  }
})();
