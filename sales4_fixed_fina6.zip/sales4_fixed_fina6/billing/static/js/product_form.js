  new TomSelect('#id_brand', { placeholder: '---------' });
  new TomSelect('#id_group', { placeholder: '---------' });

  document.querySelector('#id_photo').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('photo-preview');
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = function(ev) {
        preview.src = ev.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
  });

  function updateStockValue() {
    const price = parseFloat(document.querySelector('#id_unit_price').value) || 0;
    const stock = parseInt(document.querySelector('#id_stock').value) || 0;
    document.getElementById('stock-value').textContent = '$' + (price * stock).toFixed(2);
  }
  document.querySelector('#id_unit_price').addEventListener('input', updateStockValue);
  document.querySelector('#id_stock').addEventListener('input', updateStockValue);
  updateStockValue();
