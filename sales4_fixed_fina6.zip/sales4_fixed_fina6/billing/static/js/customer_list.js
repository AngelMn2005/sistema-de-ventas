  document.getElementById('viewCustomerModal').addEventListener('show.bs.modal', function(event) {
    const btn = event.relatedTarget;
    document.getElementById('vc-dni').textContent = btn.dataset.dni;
    document.getElementById('vc-last-name').textContent = btn.dataset.lastName;
    document.getElementById('vc-first-name').textContent = btn.dataset.firstName;
    document.getElementById('vc-email').textContent = btn.dataset.email;
    document.getElementById('vc-phone').textContent = btn.dataset.phone;
    document.getElementById('vc-address').textContent = btn.dataset.address;
    document.getElementById('vc-active').textContent = btn.dataset.active;
    document.getElementById('vc-created').textContent = btn.dataset.created;
  });
