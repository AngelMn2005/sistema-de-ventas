let PRODUCTS = {};
const tomInstances = new Map();

function fmt(n) {
  return '$' + parseFloat(n || 0).toFixed(2);
}

function getUsedIds(selfSel) {
  const used = new Set();
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const s = row.querySelector('select[name$="-product"]');
    if (s && s !== selfSel && s.value) used.add(String(s.value));
  });
  return used;
}

function buildOptions(selfSel) {
  const used = getUsedIds(selfSel);
  const current = selfSel ? selfSel.value : null;
  return Object.values(PRODUCTS)
    .filter(p => !used.has(String(p.id)) || String(p.id) === String(current))
    .map(p => ({ value: String(p.id), text: `${p.name} (${p.brand})` }));
}

function makeTomSelect(sel) {
  if (tomInstances.has(sel)) return tomInstances.get(sel);
  const ts = new TomSelect(sel, {
    placeholder: '---------',
    allowEmptyOption: true,
    maxOptions: 200,
    options: buildOptions(sel),
    onChange(val) {
      const row = sel.closest('tr');
      const priceInput = row.querySelector('input[name$="-unit_price"]');
      const p = PRODUCTS[val];
      if (priceInput) priceInput.value = p ? p.price.toFixed(2) : '';
      recalc();
      refreshAllSelects();
    }
  });
  tomInstances.set(sel, ts);
  return ts;
}

new TomSelect('#id_customer', { placeholder: '---------' });

function refreshAllSelects() {
  tomInstances.forEach((ts, sel) => {
    const current = sel.value;
    const opts = buildOptions(sel);
    ts.clearOptions();
    ts.addOptions(opts);
    if (current) ts.setValue(current, true);
  });
}

function recalc() {
  let subtotal = 0;
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const price = parseFloat(row.querySelector('[name$="-unit_price"]')?.value) || 0;
    const qty   = parseFloat(row.querySelector('[name$="-quantity"]')?.value)   || 0;
    const sub   = price * qty;
    const cell  = row.querySelector('.subtotal-cell');
    if (cell) cell.textContent = fmt(sub);
    subtotal += sub;
  });
  const iva = subtotal * 0.15;
  document.getElementById('lbl-subtotal').textContent = fmt(subtotal);
  document.getElementById('lbl-iva').textContent      = fmt(iva);
  document.getElementById('lbl-total').textContent    = fmt(subtotal + iva);
}

function hasNegativeValues() {
  let negative = false;
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const qtyInput   = row.querySelector('[name$="-quantity"]');
    const priceInput = row.querySelector('[name$="-unit_price"]');
    const qty   = parseFloat(qtyInput?.value);
    const price = parseFloat(priceInput?.value);
    if (qtyInput && !isNaN(qty) && qty < 0) {
      qtyInput.classList.add('is-invalid');
      negative = true;
    } else if (qtyInput) {
      qtyInput.classList.remove('is-invalid');
    }
    if (priceInput && !isNaN(price) && price < 0) {
      priceInput.classList.add('is-invalid');
      negative = true;
    } else if (priceInput) {
      priceInput.classList.remove('is-invalid');
    }
  });
  return negative;
}

function bindRow(row) {
  const priceInput = row.querySelector('input[name$="-unit_price"]');
  const qtyInput   = row.querySelector('input[name$="-quantity"]');
  const sel        = row.querySelector('select[name$="-product"]');

  if (priceInput) {
    priceInput.readOnly = true;
    priceInput.style.background = '#f5f5f5';
    priceInput.style.cursor = 'not-allowed';
  }

  if (sel) {
    makeTomSelect(sel);
    if (sel.value && PRODUCTS[sel.value] && priceInput && !priceInput.value) {
      priceInput.value = PRODUCTS[sel.value].price.toFixed(2);
    }
  }
  if (qtyInput) qtyInput.addEventListener('input', () => { recalc(); checkStock(); hasNegativeValues(); });
}

function deleteRow(btn) {
  const row = btn.closest('tr');
  const sel = row.querySelector('select[name$="-product"]');
  if (sel && tomInstances.has(sel)) {
    tomInstances.get(sel).destroy();
    tomInstances.delete(sel);
  }
  const cb = row.querySelector('input[type=checkbox][name$="-DELETE"]');
  if (cb) cb.checked = true;
  row.style.display = 'none';
  recalc();
  refreshAllSelects();
}

function addRow() {
  const totalInput = document.getElementById('id_details-TOTAL_FORMS');
  const idx = parseInt(totalInput.value);

  const tr = document.createElement('tr');
  tr.className = 'detail-row';
  tr.innerHTML = `
    <td>
      <select name="details-${idx}-product" id="id_details-${idx}-product">
        <option value="">---------</option>
      </select>
      <input type="hidden" name="details-${idx}-id" id="id_details-${idx}-id">
    </td>
    <td>
      <input type="number" name="details-${idx}-quantity" id="id_details-${idx}-quantity"
             class="form-control" value="1" min="1">
    </td>
    <td>
      <input type="number" name="details-${idx}-unit_price" id="id_details-${idx}-unit_price"
             class="form-control" value="" step="0.01" min="0" placeholder="0.00"
             readonly style="background:#f5f5f5; cursor:not-allowed;">
    </td>
    <td class="text-end fw-bold subtotal-cell">$0.00</td>
    <td class="text-center">
      <input type="checkbox" name="details-${idx}-DELETE" id="id_details-${idx}-DELETE" style="display:none;">
      <button type="button" class="btn btn-danger btn-sm px-2" onclick="deleteRow(this)">✕</button>
    </td>`;

  document.getElementById('formset-body').appendChild(tr);
  totalInput.value = idx + 1;
  bindRow(tr);
  recalc();
}

JSON.parse(document.getElementById('products-data').textContent).forEach(p => {
  PRODUCTS[p.id] = p;
});
document.querySelectorAll('#formset-body .detail-row').forEach(bindRow);
recalc();

function checkStock() {
  const box = document.getElementById('form-alert');
  const errs = [];

  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const sel = row.querySelector('select[name$="-product"]');
    const qty = parseInt(row.querySelector('input[name$="-quantity"]')?.value) || 0;
    const pid = sel?.value;
    if (!pid) return;
    const stock = PRODUCTS[pid]?.stock ?? Infinity;
    const pname = PRODUCTS[pid]?.name || pid;
    if (qty > stock) {
      errs.push(`"<b>${pname}</b>": solo hay <b>${stock}</b> unidad(es) en stock, solicitaste <b>${qty}</b>.`);
    }
  });

  if (errs.length) {
    box.innerHTML = '<ul class="mb-0 mt-1">' + errs.map(x => `<li>${x}</li>`).join('') + '</ul>';
    box.classList.remove('d-none');
  } else {
    box.classList.add('d-none');
    box.innerHTML = '';
  }
}

document.getElementById('invoice-form').addEventListener('submit', function(e) {
  const box = document.getElementById('form-alert');
  box.classList.add('d-none');
  const errs = [];
  let hasProduct = false;

  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const sel = row.querySelector('select[name$="-product"]');
    const qtyInput = row.querySelector('input[name$="-quantity"]');
    const priceInput = row.querySelector('input[name$="-unit_price"]');
    const qty = parseInt(qtyInput?.value) || 0;
    const qtyRaw = parseFloat(qtyInput?.value);
    const priceRaw = parseFloat(priceInput?.value);
    const pid = sel?.value;
    if (!pid) return;
    hasProduct = true;

    const pname = PRODUCTS[pid]?.name || pid;

    if (!isNaN(qtyRaw) && qtyRaw < 0) {
      errs.push(`"<b>${pname}</b>": la cantidad no puede ser negativa.`);
    }
    if (!isNaN(priceRaw) && priceRaw < 0) {
      errs.push(`"<b>${pname}</b>": el precio unitario no puede ser negativo.`);
    }

    const stock = PRODUCTS[pid]?.stock ?? Infinity;
    if (qty > stock) {
      errs.push(`"<b>${pname}</b>": solo hay <b>${stock}</b> unidad(es) en stock, solicitaste <b>${qty}</b>.`);
    }
  });

  if (!hasProduct) errs.push('Debes agregar al menos un producto a la factura.');

  if (errs.length) {
    e.preventDefault();
    box.innerHTML = errs.length === 1 && !hasProduct
      ? errs[0]
      : '<ul class="mb-0 mt-1">' + errs.map(x => `<li>${x}</li>`).join('') + '</ul>';
    box.classList.remove('d-none');
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
});
