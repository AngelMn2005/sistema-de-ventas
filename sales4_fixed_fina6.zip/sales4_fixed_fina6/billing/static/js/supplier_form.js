(function() {
  const DIGITS_ONLY_RE = /^\d*$/;
  const ECUADOR_LOCAL_CELL_RE = /^9\d{8}$/;
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function hideServerError(errorEl) {
    if (!errorEl) return;
    errorEl.classList.add('d-none');
    errorEl.classList.remove('d-block');
  }

  function setError(input, errorEl, isValid) {
    if (errorEl) {
      errorEl.classList.toggle('d-block', !isValid);
      errorEl.classList.toggle('d-none', isValid);
    }
    if (input) input.classList.toggle('is-invalid', !isValid);
    return isValid;
  }

  function normalizeLocalPhone(value) {
    let digits = (value || '').replace(/\D/g, '');
    digits = digits.replace(/^0+/, '');
    return digits;
  }

  function setupEcuadorPhoneField(options) {
    const hiddenPhone = document.querySelector(options.hiddenSelector || '#id_phone');
    const localPhone = document.querySelector(options.localSelector || '#phone_local');
    const phoneError = document.querySelector(options.errorSelector || '#phone-live-error');
    const serverError = document.querySelector(options.serverErrorSelector || '#phone-server-error');

    function syncHiddenPhone() {
      if (!hiddenPhone || !localPhone) return;
      const digits = normalizeLocalPhone(localPhone.value);
      hiddenPhone.value = digits ? '+593' + digits : '';
    }

    function validatePhone() {
      if (!localPhone) return true;

      const rawValue = localPhone.value.trim();
      if (rawValue === '') {
        hideServerError(serverError);
        syncHiddenPhone();
        return setError(localPhone, phoneError, true);
      }

      if (!DIGITS_ONLY_RE.test(rawValue)) {
        if (phoneError) phoneError.textContent = 'Solo se permiten numeros, no letras.';
        return setError(localPhone, phoneError, false);
      }

      const digits = normalizeLocalPhone(rawValue);
      localPhone.value = digits;
      syncHiddenPhone();

      const isValid = ECUADOR_LOCAL_CELL_RE.test(digits);
      if (!isValid && phoneError) {
        phoneError.textContent = 'Ingrese un celular ecuatoriano valido. Ej: 987654321.';
      }
      if (isValid) hideServerError(serverError);
      return setError(localPhone, phoneError, isValid);
    }

    if (localPhone) {
      localPhone.addEventListener('input', validatePhone);
      localPhone.addEventListener('blur', validatePhone);
    }

    return {
      input: localPhone,
      validate: validatePhone
    };
  }

  const emailInput = document.querySelector('#id_email');
  const emailError = document.getElementById('email-live-error');
  const emailServerError = document.getElementById('email-server-error');
  const phone = setupEcuadorPhoneField({});

  function validateEmail() {
    const value = emailInput.value.trim();
    hideServerError(emailServerError);
    const isValid = value === '' || EMAIL_RE.test(value);
    return setError(emailInput, emailError, isValid);
  }

  if (emailInput) {
    emailInput.addEventListener('input', validateEmail);
    emailInput.addEventListener('blur', validateEmail);
  }

  document.getElementById('supplierForm').addEventListener('submit', function(e) {
    const phoneOk = !phone.input || phone.validate();
    const emailOk = !emailInput || validateEmail();
    if (!phoneOk || !emailOk) {
      e.preventDefault();
      (phoneOk ? emailInput : phone.input).focus();
    }
  });
})();
