  document.getElementById('viewGroupModal').addEventListener('show.bs.modal', function(event) {
    const btn = event.relatedTarget;
    document.getElementById('vg-name').textContent = btn.dataset.name;
    document.getElementById('vg-active').textContent = btn.dataset.active;
    document.getElementById('vg-created').textContent = btn.dataset.created;
  });
