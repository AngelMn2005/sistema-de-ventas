  document.getElementById('viewBrandModal').addEventListener('show.bs.modal', function(event) {
    const btn = event.relatedTarget;
    document.getElementById('vb-name').textContent = btn.dataset.name;
    document.getElementById('vb-description').textContent = btn.dataset.description;
    document.getElementById('vb-active').textContent = btn.dataset.active;
    document.getElementById('vb-created').textContent = btn.dataset.created;
  });
