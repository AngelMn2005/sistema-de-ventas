(function() {
  const LETTERS_ONLY_RE = /^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s'\-]+$/;
  const DIGITS_ONLY_RE = /^\d*$/;
  const DNI_DIGITS_RE = /^\d{10}(\d{3})?$/;
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const ECUADOR_LOCAL_CELL_RE = /^9\d{8}$/;

  function hideServerError(errorEl) {
    if (!errorEl) return;
    errorEl.classList.add('d-none');
    errorEl.classList.remove('d-block');
  }

  function setError(input, errorEl, isValid) {
    if (errorEl) {
      errorEl.classList.toggle('d-block', !isValid);
      errorEl.classList.toggle('d-none', isValid);
    }
    if (input) input.classList.toggle('is-invalid', !isValid);
    return isValid;
  }

  function normalizeLocalPhone(value) {
    let digits = (value || '').replace(/\D/g, '');
    digits = digits.replace(/^0+/, '');
    return digits;
  }

  function setupEcuadorPhoneField(options) {
    const hiddenPhone = document.querySelector(options.hiddenSelector || '#id_phone');
    const localPhone = document.querySelector(options.localSelector || '#phone_local');
    const phoneError = document.querySelector(options.errorSelector || '#phone-live-error');
    const serverError = document.querySelector(options.serverErrorSelector || '#phone-server-error');

    function syncHiddenPhone() {
      if (!hiddenPhone || !localPhone) return;
      const digits = normalizeLocalPhone(localPhone.value);
      hiddenPhone.value = digits ? '+593' + digits : '';
    }

    function validatePhone() {
      if (!localPhone) return true;

      const rawValue = localPhone.value.trim();
      if (rawValue === '') {
        hideServerError(serverError);
        syncHiddenPhone();
        return setError(localPhone, phoneError, true);
      }

      if (!DIGITS_ONLY_RE.test(rawValue)) {
        if (phoneError) phoneError.textContent = 'Solo se permiten numeros, no letras.';
        return setError(localPhone, phoneError, false);
      }

      const digits = normalizeLocalPhone(rawValue);
      localPhone.value = digits;
      syncHiddenPhone();

      const isValid = ECUADOR_LOCAL_CELL_RE.test(digits);
      if (!isValid && phoneError) {
        phoneError.textContent = 'Ingrese un celular ecuatoriano valido. Ej: 987654321.';
      }
      // Solo ocultamos el error que vino del servidor una vez que el valor
      // actual ya es válido; así el usuario no pierde de vista el motivo
      // del rechazo si recién está corrigiendo el campo.
      if (isValid) hideServerError(serverError);
      return setError(localPhone, phoneError, isValid);
    }

    if (localPhone) {
      localPhone.addEventListener('input', validatePhone);
      localPhone.addEventListener('blur', validatePhone);
      // No ejecutamos validatePhone() al cargar para no ocultar un error
      // de servidor real que el usuario todavía no ha visto.
    }

    return {
      input: localPhone,
      validate: validatePhone
    };
  }

  const dniInput = document.querySelector('#id_dni');
  const dniError = document.getElementById('dni-live-error');
  const dniServerError = document.getElementById('dni-server-error');
  const firstNameInput = document.querySelector('#id_first_name');
  const firstNameError = document.getElementById('first-name-live-error');
  const firstNameServerError = document.getElementById('first-name-server-error');
  const lastNameInput = document.querySelector('#id_last_name');
  const lastNameError = document.getElementById('last-name-live-error');
  const lastNameServerError = document.getElementById('last-name-server-error');
  const emailInput = document.querySelector('#id_email');
  const emailError = document.getElementById('email-live-error');
  const emailServerError = document.getElementById('email-server-error');
  const phone = setupEcuadorPhoneField({});

  function validateDni() {
    const val = dniInput.value.trim();
    hideServerError(dniServerError);
    if (val === '') return setError(dniInput, dniError, true);

    const isValid = DIGITS_ONLY_RE.test(val) && DNI_DIGITS_RE.test(val);
    if (!DIGITS_ONLY_RE.test(val)) {
      dniError.textContent = 'La cedula / RUC solo puede contener numeros, sin letras ni guiones.';
    } else if (!DNI_DIGITS_RE.test(val)) {
      dniError.textContent = 'Debe tener exactamente 10 digitos (cedula) o 13 digitos (RUC).';
    }
    return setError(dniInput, dniError, isValid);
  }

  function validateFirstName() {
    const val = firstNameInput.value.trim();
    hideServerError(firstNameServerError);
    if (val === '') {
      firstNameError.textContent = 'El nombre es obligatorio.';
      return setError(firstNameInput, firstNameError, false);
    }
    const isValid = LETTERS_ONLY_RE.test(val);
    if (!isValid) {
      firstNameError.textContent = 'El nombre solo puede contener letras. No se permiten numeros ni caracteres especiales.';
    }
    return setError(firstNameInput, firstNameError, isValid);
  }

  function validateLastName() {
    const val = lastNameInput.value.trim();
    hideServerError(lastNameServerError);
    if (val === '') {
      lastNameError.textContent = 'El apellido es obligatorio.';
      return setError(lastNameInput, lastNameError, false);
    }
    const isValid = LETTERS_ONLY_RE.test(val);
    if (!isValid) {
      lastNameError.textContent = 'El apellido solo puede contener letras. No se permiten numeros ni caracteres especiales.';
    }
    return setError(lastNameInput, lastNameError, isValid);
  }

  function validateEmail() {
    const val = emailInput.value.trim();
    hideServerError(emailServerError);
    const isValid = val === '' || EMAIL_RE.test(val);
    return setError(emailInput, emailError, isValid);
  }

  if (dniInput) {
    dniInput.addEventListener('input', validateDni);
    dniInput.addEventListener('blur', validateDni);
  }
  if (firstNameInput) {
    firstNameInput.addEventListener('input', validateFirstName);
    firstNameInput.addEventListener('blur', validateFirstName);
  }
  if (lastNameInput) {
    lastNameInput.addEventListener('input', validateLastName);
    lastNameInput.addEventListener('blur', validateLastName);
  }
  if (emailInput) {
    emailInput.addEventListener('input', validateEmail);
    emailInput.addEventListener('blur', validateEmail);
  }

  document.getElementById('customerForm').addEventListener('submit', function(e) {
    const dniOk = !dniInput || validateDni();
    const firstOk = !firstNameInput || validateFirstName();
    const lastOk = !lastNameInput || validateLastName();
    const emailOk = !emailInput || validateEmail();
    const phoneOk = !phone.input || phone.validate();

    if (!dniOk || !firstOk || !lastOk || !emailOk || !phoneOk) {
      e.preventDefault();
      const firstInvalid = [dniInput, firstNameInput, lastNameInput, emailInput, phone.input]
        .find(el => el && el.classList.contains('is-invalid'));
      if (firstInvalid) firstInvalid.focus();
    }
  });
})();
