from django.core.validators import MinValueValidator
from decimal import Decimal
from django.db import models
from django.db.models import F, ProtectedError

from shared.validators import validate_cedula_ec, validate_ecuador_cellphone, normalize_ecuador_cellphone, validate_name, validate_no_numbers, validate_last_name


# === CATALOGS ===
class Brand(models.Model):
    """Product brand."""
    name = models.CharField(max_length=100, unique=True, verbose_name='Nombre de la Marca')
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Marca'
        verbose_name_plural = 'Marcas'
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class ProductGroup(models.Model):
    """Product category/group."""
    name = models.CharField(max_length=100, unique=True, verbose_name='Nombre del Grupo')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Grupo de Producto'
        verbose_name_plural = 'Grupos de Producto'
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class Supplier(models.Model):
    """Supplier catalog. Related to products through many-to-many."""
    name = models.CharField(max_length=200, verbose_name='Nombre de la Empresa')
    contact_name = models.CharField(max_length=200, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True, validators=[validate_ecuador_cellphone])
    address = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Proveedor'
        verbose_name_plural = 'Proveedores'
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        self.phone = normalize_ecuador_cellphone(self.phone)
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.products.exists():
            raise ProtectedError(
                f'No se puede eliminar "{self}" porque tiene productos asociados.',
                self.products.all(),
            )
        return super().delete(*args, **kwargs)


# === PRODUCT CRUD ===
class Product(models.Model):
    """Product inventory item."""
    name = models.CharField(max_length=200, verbose_name='Nombre del Producto')
    description = models.TextField(blank=True, null=True)
    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, related_name='products')
    group = models.ForeignKey(ProductGroup, on_delete=models.PROTECT, related_name='products')
    suppliers = models.ManyToManyField(Supplier, related_name='products')
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0.1)])
    stock = models.IntegerField(validators=[MinValueValidator(0)], verbose_name='Stock')
    photo = models.ImageField(upload_to='products/', blank=True, null=True, verbose_name='Foto')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} ({self.brand.name})'

    @property
    def balance(self):
        """Inventory value: unit price multiplied by stock."""
        return self.unit_price * self.stock

    def get_photo_url(self):
        """Return product photo URL or the default image."""
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url
        return '/media/products/default_product.png'


# === CUSTOMER CRUD ===
class Customer(models.Model):
    """Customer master data."""
    dni = models.CharField(
        max_length=13,
        unique=True,
        verbose_name='DNI/RUC',
        validators=[validate_cedula_ec],
    )
    first_name = models.CharField(max_length=100, validators=[validate_name, validate_no_numbers])
    last_name = models.CharField(max_length=100, validators=[validate_last_name, validate_no_numbers])
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True, validators=[validate_ecuador_cellphone])
    address = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f'{self.last_name} {self.first_name}'

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

    def save(self, *args, **kwargs):
        self.phone = normalize_ecuador_cellphone(self.phone)
        super().save(*args, **kwargs)


class CustomerProfile(models.Model):
    """Extended customer profile."""
    TAXPAYER = [
        ('final', 'Consumidor Final'),
        ('ruc', 'RUC'),
        ('rise', 'RISE'),
    ]
    PAYMENT = [
        ('cash', 'Efectivo'),
        ('credit_15', '15 días'),
        ('credit_30', '30 días'),
        ('credit_60', '60 días'),
    ]

    customer = models.OneToOneField(Customer, on_delete=models.CASCADE, related_name='profile')
    taxpayer_type = models.CharField(max_length=10, choices=TAXPAYER, default='final')
    payment_terms = models.CharField(max_length=15, choices=PAYMENT, default='cash')
    credit_limit = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Perfil de Cliente'

    def __str__(self):
        return f'Perfil: {self.customer}'


# === INVOICE CRUD ===
class Invoice(models.Model):
    """Invoice header."""
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name='invoices')
    invoice_date = models.DateTimeField(auto_now_add=True)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-invoice_date']

    def __str__(self):
        return f'Factura #{self.id} - {self.customer}'

    def recalculate(self):
        subtotal = sum((d.subtotal for d in self.details.all()), Decimal('0'))
        self.subtotal = subtotal
        self.tax = subtotal * Decimal('0.15')
        self.total = self.subtotal + self.tax
        self.save()

    def delete(self, *args, **kwargs):
        for detail in self.details.all():
            Product.objects.filter(pk=detail.product_id).update(stock=F('stock') + detail.quantity)
        super().delete(*args, **kwargs)


class InvoiceDetail(models.Model):
    """Invoice line item."""
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='details')
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name='invoice_details')
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0.1)])
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f'{self.product.name} x {self.quantity}'

    def save(self, *args, **kwargs):
        self.subtotal = self.quantity * self.unit_price
        super().save(*args, **kwargs)
        self.invoice.recalculate()
        Product.objects.filter(pk=self.product_id).update(stock=F('stock') - self.quantity)