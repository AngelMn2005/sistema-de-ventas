import json
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count, F, ProtectedError, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from shared.decorators import audit_action
from shared.export_mixin import ListExportMixin
from shared.mixin import (
    ListContextMixin,
    ProtectedDeleteMixin,
    QueryFilterMixin,
    StaffRequiredMixin,
)

from .forms import (
    BrandForm,
    CustomerForm,
    InvoiceDetailFormSet,
    InvoiceForm,
    ProductForm,
    ProductGroupForm,
    SignUpForm,
    SupplierForm,
)
from .models import Brand, Customer, Invoice, InvoiceDetail, Product, ProductGroup, Supplier


# === HOME / AUTH ===
def home(request):
    revenue_agg = Invoice.objects.filter(is_active=True).aggregate(
        total_revenue=Sum('total'),
        count=Count('id'),
    )
    total_revenue = revenue_agg['total_revenue'] or 0
    invoice_count = revenue_agg['count'] or 0
    avg_ticket = (total_revenue / invoice_count) if invoice_count else 0

    top_products_qs = (
        InvoiceDetail.objects.values('product__name')
        .annotate(qty=Sum('quantity'))
        .order_by('-qty')[:5]
    )

    context = {
        'total_brands': Brand.objects.count(),
        'total_products': Product.objects.count(),
        'total_customers': Customer.objects.count(),
        'total_invoices': Invoice.objects.count(),
        'total_revenue': total_revenue,
        'avg_ticket': avg_ticket,
        'recent_invoices': Invoice.objects.all()[:5],
        'low_stock': Product.objects.filter(stock__lte=10, is_active=True),
        'top_products_labels': [p['product__name'] for p in top_products_qs],
        'top_products_data': [p['qty'] for p in top_products_qs],
    }
    return render(request, 'billing/home.html', context)


class SignUpView(CreateView):
    form_class = SignUpForm
    template_name = 'registration/signup.html'
    success_url = reverse_lazy('billing:brand_list')

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        return response


# === CRUD BRAND ===
@method_decorator(audit_action("LIST_BRANDS"), name='dispatch')
class BrandListView(ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Brand
    template_name = 'billing/brand_list.html'
    context_object_name = 'brands'
    paginate_by = 5
    page_title = 'Marcas'
    simple_filters = {'name': 'name__icontains'}
    export_title = 'Marcas'
    export_filename = 'marcas'
    export_fields = [
        ('Nombre', 'name'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        return self.apply_list_filters(super().get_queryset())


@login_required
@audit_action("CREATE_BRAND")
def brand_create(request):
    if request.method == 'POST':
        form = BrandForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '¡Marca creada!')
            return redirect('billing:brand_list')
    else:
        form = BrandForm()
    return render(request, 'billing/brand_form.html', {'form': form, 'title': 'Crear Marca'})


@login_required
@audit_action("UPDATE_BRAND")
def brand_update(request, pk):
    brand = get_object_or_404(Brand, pk=pk)
    if request.method == 'POST':
        form = BrandForm(request.POST, instance=brand)
        if form.is_valid():
            form.save()
            messages.success(request, '¡Marca actualizada!')
            return redirect('billing:brand_list')
    else:
        form = BrandForm(instance=brand)
    return render(request, 'billing/brand_form.html', {'form': form, 'title': 'Editar Marca'})


@login_required
@audit_action("DELETE_BRAND")
def brand_delete(request, pk):
    if not request.user.is_staff:
        messages.error(request, 'Solo usuarios staff pueden eliminar registros.')
        return redirect('billing:brand_list')

    brand = get_object_or_404(Brand, pk=pk)
    if request.method == 'POST':
        try:
            brand.delete()
            messages.success(request, '¡Marca eliminada!')
        except ProtectedError:
            messages.error(
                request,
                f'No se puede eliminar "{brand.name}" porque tiene productos asociados. '
                'Reasigna o elimina esos productos primero.',
            )
        return redirect('billing:brand_list')
    return render(request, 'billing/brand_confirm_delete.html', {'object': brand})


# === CRUD PRODUCT GROUP ===
class ProductGroupListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = ProductGroup
    template_name = 'billing/productgroup_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Grupos de Producto'
    simple_filters = {'name': 'name__icontains'}
    export_title = 'Grupos de Producto'
    export_filename = 'grupos_de_producto'
    export_fields = [
        ('Nombre', 'name'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        return self.apply_list_filters(super().get_queryset())


class ProductGroupCreateView(LoginRequiredMixin, CreateView):
    model = ProductGroup
    form_class = ProductGroupForm
    template_name = 'billing/productgroup_form.html'
    success_url = reverse_lazy('billing:productgroup_list')


class ProductGroupUpdateView(LoginRequiredMixin, UpdateView):
    model = ProductGroup
    form_class = ProductGroupForm
    template_name = 'billing/productgroup_form.html'
    success_url = reverse_lazy('billing:productgroup_list')


class ProductGroupDeleteView(LoginRequiredMixin, StaffRequiredMixin, ProtectedDeleteMixin, DeleteView):
    model = ProductGroup
    template_name = 'billing/productgroup_confirm_delete.html'
    success_url = reverse_lazy('billing:productgroup_list')
    staff_redirect_url = reverse_lazy('billing:productgroup_list')
    protected_error_message = 'No se puede eliminar el grupo "{obj}" porque tiene productos asociados.'


# === CRUD SUPPLIER ===
class SupplierListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Supplier
    template_name = 'billing/supplier_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Proveedores'
    simple_filters = {
        'name': 'name__icontains',
        'contact_name': 'contact_name__icontains',
        'email': 'email__icontains',
        'phone': 'phone__icontains',
    }
    export_title = 'Proveedores'
    export_filename = 'proveedores'
    export_fields = [
        ('Nombre', 'name'),
        ('Contacto', 'contact_name'),
        ('Correo', 'email'),
        ('Teléfono', 'phone'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        return self.apply_list_filters(super().get_queryset())


class SupplierCreateView(LoginRequiredMixin, CreateView):
    model = Supplier
    form_class = SupplierForm
    template_name = 'billing/supplier_form.html'
    success_url = reverse_lazy('billing:supplier_list')


class SupplierUpdateView(LoginRequiredMixin, UpdateView):
    model = Supplier
    form_class = SupplierForm
    template_name = 'billing/supplier_form.html'
    success_url = reverse_lazy('billing:supplier_list')


class SupplierDeleteView(LoginRequiredMixin, StaffRequiredMixin, ProtectedDeleteMixin, DeleteView):
    model = Supplier
    template_name = 'billing/supplier_confirm_delete.html'
    success_url = reverse_lazy('billing:supplier_list')
    staff_redirect_url = reverse_lazy('billing:supplier_list')


# === CRUD PRODUCT ===
class ProductListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Product
    template_name = 'billing/product_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Productos'
    simple_filters = {
        'name': 'name__icontains',
        'brand': 'brand_id',
        'group': 'group_id',
        'supplier': 'suppliers__id',
    }
    range_filters = {
        'price_min': 'unit_price__gte',
        'price_max': 'unit_price__lte',
        'stock_min': 'stock__gte',
        'stock_max': 'stock__lte',
    }
    export_title = 'Productos'
    export_filename = 'productos'
    export_fields = [
        ('Nombre', 'name'),
        ('Marca', 'brand.name'),
        ('Grupo', 'group.name'),
        ('Precio', 'unit_price'),
        ('Stock', 'stock'),
        ('Saldo', 'balance'),
        ('Proveedores', lambda p: ', '.join(s.name for s in p.suppliers.all())),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        qs = super().get_queryset().select_related('brand', 'group').prefetch_related('suppliers')
        return self.apply_list_filters(qs).distinct()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['brands'] = Brand.objects.all()
        context['groups'] = ProductGroup.objects.all()
        context['suppliers'] = Supplier.objects.all()
        return context


class ProductCreateView(LoginRequiredMixin, CreateView):
    model = Product
    form_class = ProductForm
    template_name = 'billing/product_form.html'
    success_url = reverse_lazy('billing:product_list')


class ProductUpdateView(LoginRequiredMixin, UpdateView):
    model = Product
    form_class = ProductForm
    template_name = 'billing/product_form.html'
    success_url = reverse_lazy('billing:product_list')


class ProductDeleteView(LoginRequiredMixin, StaffRequiredMixin, ProtectedDeleteMixin, DeleteView):
    model = Product
    template_name = 'billing/product_confirm_delete.html'
    success_url = reverse_lazy('billing:product_list')
    staff_redirect_url = reverse_lazy('billing:product_list')
    protected_error_message = 'No se puede eliminar "{obj}" porque tiene registros relacionados.'


# === CRUD CUSTOMER ===
class CustomerListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Customer
    template_name = 'billing/customer_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Clientes'
    simple_filters = {
        'dni': 'dni__icontains',
        'last_name': 'last_name__icontains',
        'first_name': 'first_name__icontains',
        'email': 'email__icontains',
    }
    export_title = 'Clientes'
    export_filename = 'clientes'
    export_fields = [
        ('DNI/RUC', 'dni'),
        ('Apellido', 'last_name'),
        ('Nombre', 'first_name'),
        ('Correo', 'email'),
        ('Teléfono', 'phone'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        return self.apply_list_filters(super().get_queryset())


class CustomerCreateView(LoginRequiredMixin, CreateView):
    model = Customer
    form_class = CustomerForm
    template_name = 'billing/customer_form.html'
    success_url = reverse_lazy('billing:customer_list')


class CustomerUpdateView(LoginRequiredMixin, UpdateView):
    model = Customer
    form_class = CustomerForm
    template_name = 'billing/customer_form.html'
    success_url = reverse_lazy('billing:customer_list')


class CustomerDeleteView(LoginRequiredMixin, StaffRequiredMixin, ProtectedDeleteMixin, DeleteView):
    model = Customer
    template_name = 'billing/customer_confirm_delete.html'
    success_url = reverse_lazy('billing:customer_list')
    staff_redirect_url = reverse_lazy('billing:customer_list')
    protected_error_message = 'No se puede eliminar a "{obj}" porque tiene facturas asociadas.'


# === CRUD INVOICE ===
class InvoiceListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Invoice
    template_name = 'billing/invoice_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Facturas'
    range_filters = {
        'date_from': 'invoice_date__date__gte',
        'date_to': 'invoice_date__date__lte',
        'total_min': 'total__gte',
        'total_max': 'total__lte',
    }
    export_title = 'Facturas'
    export_filename = 'facturas'
    export_fields = [
        ('Factura', 'id'),
        ('Cliente', 'customer'),
        ('Fecha', 'invoice_date'),
        ('Subtotal', 'subtotal'),
        ('Impuesto', 'tax'),
        ('Total', 'total'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        qs = super().get_queryset().select_related('customer')
        customer = self.request.GET.get('customer', '').strip()
        if customer:
            qs = qs.filter(
                Q(customer__first_name__icontains=customer)
                | Q(customer__last_name__icontains=customer)
                | Q(customer__dni__icontains=customer)
            )
        return self.apply_list_filters(qs)


@login_required
def invoice_create(request):
    available_products = Product.objects.filter(stock__gt=0, is_active=True).select_related('brand')
    if not available_products.exists():
        messages.error(request, 'No se puede crear una factura: no hay productos con stock disponible.')
        return redirect('billing:invoice_list')
    products_data = [
        {
            'id':    p.id,
            'name':  p.name,
            'brand': p.brand.name,
            'price': round(float(p.unit_price), 2),
            'stock': p.stock,
        }
        for p in available_products
    ]

    if request.method == 'POST':
        form    = InvoiceForm(request.POST)
        formset = InvoiceDetailFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            stock_errors = []
            for detail_form in formset:
                if not detail_form.cleaned_data or detail_form.cleaned_data.get('DELETE'):
                    continue
                product  = detail_form.cleaned_data.get('product')
                quantity = detail_form.cleaned_data.get('quantity', 0)
                if product and quantity and quantity > product.stock:
                    stock_errors.append(
                        f'"{product.name}": solo hay {product.stock} unidad(es) en stock, solicitaste {quantity}.'
                    )

            if stock_errors:
                for error in stock_errors:
                    messages.error(request, error)
            else:
                invoice = form.save(commit=False)
                invoice.save()
                formset.instance = invoice
                formset.save()

                for detail in invoice.details.all():
                    Product.objects.filter(pk=detail.product_id).update(stock=F('stock') - detail.quantity)

                subtotal         = sum((d.subtotal for d in invoice.details.all()), Decimal('0'))
                invoice.subtotal = subtotal.quantize(Decimal('0.01'))
                invoice.tax      = (subtotal * Decimal('0.15')).quantize(Decimal('0.01'))
                invoice.total    = (invoice.subtotal + invoice.tax).quantize(Decimal('0.01'))
                invoice.save()

                messages.success(request, f'¡Factura #{invoice.id} creada! Total: ${invoice.total}')
                return redirect('billing:invoice_list')
        else:
            # Los errores de cada línea (cantidad/precio negativos, producto
            # vacío, etc.) ya se muestran junto a cada campo en la tabla.
            if not formset.is_valid():
                messages.error(request, 'Revisa los errores marcados en el detalle de la factura.')
            if not form.is_valid():
                messages.error(request, 'Revisa los errores marcados en el formulario.')
    else:
        form    = InvoiceForm()
        formset = InvoiceDetailFormSet()

    return render(request, 'billing/invoice_form.html', {
        'form':               form,
        'formset':            formset,
        'title':              'Crear Factura',
        'available_products': available_products,
        'products_data':      products_data,
    })


@login_required
def invoice_detail(request, pk):
    invoice = get_object_or_404(
        Invoice.objects.select_related('customer').prefetch_related('details__product'),
        pk=pk,
    )
    return render(request, 'billing/invoice_detail.html', {'invoice': invoice})


@login_required
def invoice_delete(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    if request.method == 'POST':
        invoice_id = invoice.id
        for detail in invoice.details.all():
            Product.objects.filter(pk=detail.product_id).update(stock=F('stock') + detail.quantity)
        invoice.delete()
        messages.success(request, f'¡Factura #{invoice_id} eliminada! El stock fue restaurado.')
        return redirect('billing:invoice_list')
    return render(request, 'billing/invoice_confirm_delete.html', {'object': invoice})
