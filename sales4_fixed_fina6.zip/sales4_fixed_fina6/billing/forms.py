import re
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import Brand, Product, ProductGroup, Supplier, Customer, Invoice, InvoiceDetail
from shared.validators import normalize_ecuador_cellphone
from django.forms import inlineformset_factory


class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    first_name = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields:
            self.fields[f].widget.attrs['class'] = 'form-control'


class BrandForm(forms.ModelForm):
    class Meta:
        model = Brand
        fields = ['name', 'description', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese el nombre de la marca',
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Descripción de la marca (opcional)',
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'role': 'switch',
            }),
        }
        labels = {
            'name': 'Nombre de la Marca',
            'description': 'Descripción',
            'is_active': 'Activo',
        }

    def clean_name(self):
        name = (self.cleaned_data.get('name') or '').strip()
        qs = Brand.objects.filter(name__iexact=name)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError(f'Ya existe una marca con el nombre "{name}".')
        return name


class ProductGroupForm(forms.ModelForm):
    class Meta:
        model = ProductGroup
        fields = ['name', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese el nombre del grupo',
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'role': 'switch',
            }),
        }
        labels = {
            'name': 'Nombre del Grupo',
            'is_active': 'Activo',
        }

    def clean_name(self):
        name = (self.cleaned_data.get('name') or '').strip()
        qs = ProductGroup.objects.filter(name__iexact=name)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError(f'Ya existe un grupo con el nombre "{name}".')
        return name


class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ['name', 'contact_name', 'email', 'phone', 'address', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese el nombre de la empresa',
            }),
            'contact_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Persona de contacto (opcional)',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'correo@ejemplo.com',
            }),
            'phone': forms.HiddenInput(),
            'address': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Dirección (opcional)',
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'role': 'switch',
            }),
        }
        labels = {
            'name': 'Nombre de la Empresa',
            'contact_name': 'Nombre de Contacto',
            'email': 'Correo Electrónico',
            'phone': 'Teléfono',
            'address': 'Dirección',
            'is_active': 'Activo',
        }

    def clean_name(self):
        name = (self.cleaned_data.get('name') or '').strip()
        if any(char.isdigit() for char in name):
            raise ValidationError('El nombre de la empresa no puede contener números.')
        qs = Supplier.objects.filter(name__iexact=name)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError(f'Ya existe un proveedor con el nombre "{name}".')
        return name

    def clean_phone(self):
        phone = (self.cleaned_data.get('phone') or '').strip()
        if not phone:
            return phone
        normalized = normalize_ecuador_cellphone(phone)
        digits = normalized[1:] if normalized.startswith('+') else normalized
        if not digits.isdigit():
            raise ValidationError('El celular solo debe contener números.')
        if not (digits.startswith('5939') and len(digits) == 12):
            raise ValidationError(
                'Ingrese un celular ecuatoriano válido. Ej: 0987654321 o +593987654321.'
            )
        return normalized
    

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'brand', 'group', 'suppliers',
                  'unit_price', 'stock', 'photo', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese el nombre del producto',
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Descripción del producto (opcional)',
            }),
            'brand': forms.Select(attrs={
                'class': 'form-select',
            }),
            'group': forms.Select(attrs={
                'class': 'form-select',
            }),
            'suppliers': forms.SelectMultiple(attrs={
                'class': 'form-select',
                'size': '5',
            }),
            'unit_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '0.00',
                'min': '0.01',
                'step': '0.01',
                'id': 'id_unit_price',
            }),
            'stock': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '0',
                'min': '0',
                'id': 'id_stock',
            }),
            'photo': forms.ClearableFileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*',
                'id': 'id_photo',
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'role': 'switch',
            }),
        }
        labels = {
            'name': 'Nombre del Producto',
            'description': 'Descripción',
            'brand': 'Marca',
            'group': 'Grupo de Producto',
            'suppliers': 'Proveedores',
            'unit_price': 'Precio Unitario ($)',
            'stock': 'Stock',
            'photo': 'Foto del Producto',
            'is_active': 'Activo',
        }
        help_texts = {
            'suppliers': 'Mantenga presionado Ctrl (Cmd en Mac) para seleccionar varios proveedores.',
        }

    def clean_unit_price(self):
        price = self.cleaned_data.get('unit_price')
        if price is not None and price <= 0:
            raise ValidationError('El precio debe ser mayor a 0.')
        return price

    def clean_name(self):
        name = (self.cleaned_data.get('name') or '').strip()
        qs = Product.objects.filter(name__iexact=name)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError(f'Ya existe un producto con el nombre "{name}".')
        return name
    
class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['dni', 'first_name', 'last_name', 'email', 'phone', 'address', 'is_active']
        widgets = {
            'dni': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'ej. 0102030405',
                'maxlength': '13',
            }),
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nombre',
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Apellido',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'correo@ejemplo.com',
            }),
            'phone': forms.HiddenInput(),
            'address': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Dirección (opcional)',
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'role': 'switch',
            }),
        }
        labels = {
            'dni': 'DNI / RUC',
            'first_name': 'Nombres',
            'last_name': 'Apellidos',
            'email': 'Correo Electrónico',
            'phone': 'Teléfono',
            'address': 'Dirección',
            'is_active': 'Activo',
        }
        help_texts = {
            'dni': 'Cédula ecuatoriana (10 dígitos) o RUC (13 dígitos).',
        }

    def clean_dni(self):
        dni = (self.cleaned_data.get('dni') or '').strip()
        # Unicidad (excluir el propio registro en edición)
        qs = Customer.objects.filter(dni=dni)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError('Ya existe un cliente registrado con este DNI / RUC.')
        return dni

    def clean_phone(self):
        phone = (self.cleaned_data.get('phone') or '').strip()
        if not phone:
            return phone
        normalized = normalize_ecuador_cellphone(phone)
        digits = normalized[1:] if normalized.startswith('+') else normalized
        if not digits.isdigit():
            raise ValidationError('El celular solo debe contener números.')
        if not (digits.startswith('5939') and len(digits) == 12):
            raise ValidationError(
                'Ingrese un celular ecuatoriano válido. Ej: 0987654321 o +593987654321.'
            )
        return normalized



class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ['customer']

        widgets = {
            'customer': forms.Select(
                attrs={'class': 'form-select'}
            ),
        }
class InvoiceDetailForm(forms.ModelForm):
    class Meta:
        model = InvoiceDetail
        fields = ['product', 'quantity', 'unit_price']
        widgets = {
            'product': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'unit_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Exclude products with stock = 0 from the dropdown
        self.fields['product'].queryset = Product.objects.filter(
            stock__gt=0, is_active=True
        ).select_related('brand')

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity is not None and quantity < 1:
            raise ValidationError('La cantidad no puede ser negativa ni cero.')
        return quantity

    def clean_unit_price(self):
        unit_price = self.cleaned_data.get('unit_price')
        if unit_price is not None and unit_price < 0:
            raise ValidationError('El precio unitario no puede ser negativo.')
        return unit_price

InvoiceDetailFormSet = inlineformset_factory(Invoice, InvoiceDetail,
    form=InvoiceDetailForm,
    extra=1,
    can_delete=True,
)
