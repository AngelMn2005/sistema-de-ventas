# Generated manually after adding Ecuadorian cellphone validation.

import shared.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('billing', '0007_alter_brand_options_alter_productgroup_options_and_more'),
    ]

    operations = [
        migrations.AlterField(
            model_name='customer',
            name='phone',
            field=models.CharField(
                blank=True,
                max_length=20,
                null=True,
                validators=[shared.validators.validate_ecuador_cellphone],
            ),
        ),
        migrations.AlterField(
            model_name='supplier',
            name='phone',
            field=models.CharField(
                blank=True,
                max_length=20,
                null=True,
                validators=[shared.validators.validate_ecuador_cellphone],
            ),
        ),
    ]
