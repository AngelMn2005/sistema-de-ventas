let PRODUCTS = {};
const tomInstances = new Map();

function fmt(n) {
  return '$' + parseFloat(n || 0).toFixed(2);
}

function getUsedIds(selfSel) {
  const used = new Set();
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const s = row.querySelector('select[name$="-product"]');
    if (s && s !== selfSel && s.value) used.add(String(s.value));
  });
  return used;
}

function getSelectedSupplierId() {
  const sel = document.getElementById('id_supplier');
  return sel ? sel.value : '';
}

function buildOptions(selfSel) {
  const used = getUsedIds(selfSel);
  const current = selfSel ? selfSel.value : null;
  const supplierId = getSelectedSupplierId();
  return Object.values(PRODUCTS)
    .filter(p => {
      const matchesSupplier = !supplierId || p.suppliers.includes(parseInt(supplierId));
      const notUsed = !used.has(String(p.id)) || String(p.id) === String(current);
      return matchesSupplier && notUsed;
    })
    .map(p => ({ value: String(p.id), text: `${p.name} (${p.brand})` }));
}

function makeTomSelect(sel) {
  if (tomInstances.has(sel)) return tomInstances.get(sel);
  const ts = new TomSelect(sel, {
    placeholder: '---------',
    allowEmptyOption: true,
    maxOptions: 200,
    options: buildOptions(sel),
    onChange(val) {
      // Si no hay proveedor elegido, auto-asignar el primero del producto
      if (val && !document.getElementById('id_supplier').value) {
        const p = PRODUCTS[val];
        if (p && p.suppliers.length > 0) {
          supplierTomSelect.setValue(String(p.suppliers[0]), false);
          refreshAllSelects();
        }
      }
      recalc();
      refreshAllSelects();
    }
  });
  tomInstances.set(sel, ts);
  return ts;
}

const supplierTomSelect = new TomSelect('#id_supplier', {
  placeholder: '---------',
  onChange(val) {
    // Al cambiar proveedor, limpiar productos seleccionados que no pertenecen a ese proveedor
    document.querySelectorAll('#formset-body .detail-row').forEach(row => {
      if (row.style.display === 'none') return;
      const sel = row.querySelector('select[name$="-product"]');
      if (!sel) return;
      const currentVal = sel.value;
      if (currentVal && val) {
        const p = PRODUCTS[currentVal];
        if (p && !p.suppliers.includes(parseInt(val))) {
          const ts = tomInstances.get(sel);
          if (ts) ts.setValue('', true);
        }
      }
    });
    refreshAllSelects();
    recalc();
  }
});

function refreshAllSelects() {
  tomInstances.forEach((ts, sel) => {
    const current = sel.value;
    const opts = buildOptions(sel);
    ts.clearOptions();
    ts.addOptions(opts);
    if (current) ts.setValue(current, true);
  });
}

function recalc() {
  let subtotal = 0;
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const cost = parseFloat(row.querySelector('[name$="-unit_cost"]')?.value) || 0;
    const qty  = parseFloat(row.querySelector('[name$="-quantity"]')?.value)  || 0;
    const sub  = cost * qty;
    const cell = row.querySelector('.subtotal-cell');
    if (cell) cell.textContent = fmt(sub);
    subtotal += sub;
  });
  const iva = subtotal * 0.15;
  document.getElementById('lbl-subtotal').textContent = fmt(subtotal);
  document.getElementById('lbl-iva').textContent      = fmt(iva);
  document.getElementById('lbl-total').textContent    = fmt(subtotal + iva);
}

function hasNegativeValues() {
  let negative = false;
  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const qtyInput  = row.querySelector('[name$="-quantity"]');
    const costInput = row.querySelector('[name$="-unit_cost"]');
    const qty  = parseFloat(qtyInput?.value);
    const cost = parseFloat(costInput?.value);
    if (qtyInput && !isNaN(qty) && qty < 0) {
      qtyInput.classList.add('is-invalid');
      negative = true;
    } else if (qtyInput) {
      qtyInput.classList.remove('is-invalid');
    }
    if (costInput && !isNaN(cost) && cost < 0) {
      costInput.classList.add('is-invalid');
      negative = true;
    } else if (costInput) {
      costInput.classList.remove('is-invalid');
    }
  });
  return negative;
}

function bindRow(row) {
  const costInput = row.querySelector('input[name$="-unit_cost"]');
  const qtyInput  = row.querySelector('input[name$="-quantity"]');
  const sel       = row.querySelector('select[name$="-product"]');

  if (sel) makeTomSelect(sel);
  if (qtyInput) qtyInput.addEventListener('input', () => { recalc(); hasNegativeValues(); });
  if (costInput) costInput.addEventListener('input', () => { recalc(); hasNegativeValues(); });
}

function deleteRow(btn) {
  const row = btn.closest('tr');
  const sel = row.querySelector('select[name$="-product"]');
  if (sel && tomInstances.has(sel)) {
    tomInstances.get(sel).destroy();
    tomInstances.delete(sel);
  }
  const cb = row.querySelector('input[type=checkbox][name$="-DELETE"]');
  if (cb) cb.checked = true;
  row.style.display = 'none';
  recalc();
  refreshAllSelects();
}

function addRow() {
  const totalInput = document.getElementById('id_details-TOTAL_FORMS');
  const idx = parseInt(totalInput.value);

  const tr = document.createElement('tr');
  tr.className = 'detail-row';
  tr.innerHTML = `
    <td>
      <select name="details-${idx}-product" id="id_details-${idx}-product">
        <option value="">---------</option>
      </select>
      <input type="hidden" name="details-${idx}-id" id="id_details-${idx}-id">
    </td>
    <td>
      <input type="number" name="details-${idx}-quantity" id="id_details-${idx}-quantity"
             class="form-control" value="1" min="1">
    </td>
    <td>
      <input type="number" name="details-${idx}-unit_cost" id="id_details-${idx}-unit_cost"
             class="form-control" value="" step="0.01" min="0" placeholder="0.00">
    </td>
    <td class="text-end fw-bold subtotal-cell">$0.00</td>
    <td class="text-center">
      <input type="checkbox" name="details-${idx}-DELETE" id="id_details-${idx}-DELETE" style="display:none;">
      <button type="button" class="btn btn-danger btn-sm px-2" onclick="deleteRow(this)">✕</button>
    </td>`;

  document.getElementById('formset-body').appendChild(tr);
  totalInput.value = idx + 1;
  bindRow(tr);
  recalc();
}

JSON.parse(document.getElementById('products-data').textContent).forEach(p => {
  PRODUCTS[p.id] = p;
});
document.querySelectorAll('#formset-body .detail-row').forEach(bindRow);
recalc();

document.getElementById('purchase-form').addEventListener('submit', function(e) {
  const box = document.getElementById('form-alert');
  box.classList.add('d-none');
  let hasProduct = false;
  const errs = [];

  document.querySelectorAll('#formset-body .detail-row').forEach(row => {
    if (row.style.display === 'none') return;
    const sel = row.querySelector('select[name$="-product"]');
    if (sel && sel.value) hasProduct = true;

    const qtyInput  = row.querySelector('input[name$="-quantity"]');
    const costInput = row.querySelector('input[name$="-unit_cost"]');
    const qty  = parseFloat(qtyInput?.value);
    const cost = parseFloat(costInput?.value);
    const pname = sel?.value ? (PRODUCTS[sel.value]?.name || sel.value) : 'Producto';

    if (sel && sel.value && !isNaN(qty) && qty < 0) {
      errs.push(`"<b>${pname}</b>": la cantidad no puede ser negativa.`);
    }
    if (sel && sel.value && !isNaN(cost) && cost < 0) {
      errs.push(`"<b>${pname}</b>": el costo unitario no puede ser negativo.`);
    }
  });

  if (!hasProduct) {
    errs.push('Debes agregar al menos un producto a la compra.');
  }

  if (errs.length) {
    e.preventDefault();
    box.innerHTML = errs.length === 1
      ? errs[0]
      : '<ul class="mb-0 mt-1">' + errs.map(x => `<li>${x}</li>`).join('') + '</ul>';
    box.classList.remove('d-none');
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
});
