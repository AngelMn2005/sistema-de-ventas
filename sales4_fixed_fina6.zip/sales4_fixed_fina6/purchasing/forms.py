from django import forms
from django.forms import inlineformset_factory

from billing.models import Product
from .models import Purchase, PurchaseDetail


class PurchaseForm(forms.ModelForm):
    class Meta:
        model = Purchase
        fields = ['supplier', 'document_number']
        widgets = {
            'supplier': forms.Select(attrs={
                'class': 'form-select',
            }),
            'document_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej. FAC-001-2026',
            }),
        }
        labels = {
            'supplier': 'Proveedor',
            'document_number': 'N° Factura del Proveedor',
        }


class PurchaseDetailForm(forms.ModelForm):
    class Meta:
        model = PurchaseDetail
        fields = ['product', 'quantity', 'unit_cost']
        widgets = {
            'product': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'unit_cost': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01','autofocus': True }),
        }
        labels = {
            'product': 'Producto',
            'quantity': 'Cantidad',
            'unit_cost': 'Costo unit.',
        }


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # A diferencia de la venta, en una compra se puede elegir cualquier
        # producto activo, sin importar el stock actual (la compra lo reabastece).
        self.fields['product'].queryset = Product.objects.filter(
            is_active=True
        ).select_related('brand')

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity is not None and quantity < 1:
            raise forms.ValidationError('La cantidad no puede ser negativa ni cero.')
        return quantity

    def clean_unit_cost(self):
        unit_cost = self.cleaned_data.get('unit_cost')
        if unit_cost is not None and unit_cost < 0:
            raise forms.ValidationError('El costo unitario no puede ser negativo.')
        return unit_cost


PurchaseDetailFormSet = inlineformset_factory(
    Purchase, PurchaseDetail,
    form=PurchaseDetailForm,
    extra=1,
    can_delete=True,
)
