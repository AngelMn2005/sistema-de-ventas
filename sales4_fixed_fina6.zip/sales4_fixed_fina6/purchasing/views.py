from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import F
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import ListView

from billing.models import Product
from shared.export_mixin import ListExportMixin
from shared.mixin import ListContextMixin, QueryFilterMixin

from .forms import PurchaseDetailFormSet, PurchaseForm
from .models import Purchase


def generate_purchase_document_number():
    """
    Genera un N° de factura de proveedor automático y único, con el
    formato FAC-AAAAMMDD-NNN (NNN = secuencial del día). El usuario puede
    editarlo libremente antes de guardar la compra.
    """
    today = timezone.localdate()
    prefix = f'FAC-{today.strftime("%Y%m%d")}-'
    count_today = Purchase.objects.filter(document_number__startswith=prefix).count()
    return f'{prefix}{count_today + 1:03d}'


# === CRUD PURCHASE ===
class PurchaseListView(LoginRequiredMixin, ListContextMixin, QueryFilterMixin, ListExportMixin, ListView):
    model = Purchase
    template_name = 'purchasing/purchase_list.html'
    context_object_name = 'items'
    paginate_by = 5
    page_title = 'Compras'
    range_filters = {
        'date_from': 'purchase_date__date__gte',
        'date_to': 'purchase_date__date__lte',
        'total_min': 'total__gte',
        'total_max': 'total__lte',
    }
    export_title = 'Compras'
    export_filename = 'compras'
    export_fields = [
        ('Compra', 'id'),
        ('Proveedor', 'supplier'),
        ('N° Factura', 'document_number'),
        ('Fecha', 'purchase_date'),
        ('Subtotal', 'subtotal'),
        ('Impuesto', 'tax'),
        ('Total', 'total'),
        ('Activo', 'is_active'),
    ]

    def get_queryset(self):
        qs = super().get_queryset().select_related('supplier')
        supplier = self.request.GET.get('supplier', '').strip()
        if supplier:
            qs = qs.filter(supplier__name__icontains=supplier)
        return self.apply_list_filters(qs)


@login_required
def purchase_create(request):
    available_products = Product.objects.filter(is_active=True).select_related('brand').prefetch_related('suppliers')
    if not available_products.exists():
        messages.error(request, 'No se puede registrar una compra: no hay productos activos.')
        return redirect('purchasing:purchase_list')
    products_data = [
        {
            'id':        p.id,
            'name':      p.name,
            'brand':     p.brand.name,
            'price':     round(float(p.unit_price), 2),
            'stock':     p.stock,
            'suppliers': [s.id for s in p.suppliers.all()],
        }
        for p in available_products
    ]

    if request.method == 'POST':
        form    = PurchaseForm(request.POST)
        formset = PurchaseDetailFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            has_product = any(
                f.cleaned_data and not f.cleaned_data.get('DELETE')
                for f in formset
            )
            if not has_product:
                messages.error(request, 'Debes agregar al menos un producto a la compra.')
            else:
                purchase = form.save(commit=False)
                purchase.save()
                formset.instance = purchase
                formset.save()

                for detail in purchase.details.all():
                    Product.objects.filter(pk=detail.product_id).update(stock=F('stock') + detail.quantity)

                subtotal          = sum((d.subtotal for d in purchase.details.all()), Decimal('0'))
                purchase.subtotal = subtotal.quantize(Decimal('0.01'))
                purchase.tax      = (subtotal * Decimal('0.15')).quantize(Decimal('0.01'))
                purchase.total    = (purchase.subtotal + purchase.tax).quantize(Decimal('0.01'))
                purchase.save()

                messages.success(request, f'¡Compra #{purchase.id} registrada! Total: ${purchase.total}')
                return redirect('purchasing:purchase_list')
        else:
            # Los errores de cada línea (cantidad/costo negativos, producto
            # vacío, etc.) ya se muestran junto a cada campo en la tabla.
            if not formset.is_valid():
                messages.error(request, 'Revisa los errores marcados en el detalle de la compra.')
            if not form.is_valid():
                messages.error(request, 'Revisa los errores marcados en el formulario.')
    else:
        form    = PurchaseForm(initial={'document_number': generate_purchase_document_number()})
        formset = PurchaseDetailFormSet()

    return render(request, 'purchasing/purchase_form.html', {
        'form':               form,
        'formset':            formset,
        'title':              'Registrar Compra',
        'available_products': available_products,
        'products_data':      products_data,
    })


@login_required
def purchase_detail(request, pk):
    purchase = get_object_or_404(
        Purchase.objects.select_related('supplier').prefetch_related('details__product'),
        pk=pk,
    )
    return render(request, 'purchasing/purchase_detail.html', {'purchase': purchase})


@login_required
def purchase_delete(request, pk):
    purchase = get_object_or_404(Purchase, pk=pk)
    if request.method == 'POST':
        purchase_id = purchase.id
        for detail in purchase.details.all():
            Product.objects.filter(pk=detail.product_id).update(stock=F('stock') - detail.quantity)
        purchase.delete()
        messages.success(request, f'¡Compra #{purchase_id} eliminada! El stock fue revertido.')
        return redirect('purchasing:purchase_list')
    return render(request, 'purchasing/purchase_confirm_delete.html', {'object': purchase})
