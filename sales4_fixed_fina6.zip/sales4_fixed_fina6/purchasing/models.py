from decimal import Decimal

from django.db import models
from django.core.validators import MinValueValidator
from django.db.models import F

from billing.models import Supplier, Product  # Reutilizamos modelos de billing


# === PURCHASE CRUD ===
class Purchase(models.Model):
    """Purchase header. Documents an acquisition from a supplier."""
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name='purchases')
    document_number = models.CharField(
        max_length=20, verbose_name='Supplier Invoice No.'
    )
    purchase_date = models.DateTimeField(auto_now_add=True)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Compra'
        verbose_name_plural = 'Compras'
        ordering = ['-purchase_date']

    def __str__(self):
        return f'Compra #{self.id} - {self.supplier}'

    def recalculate(self):
        subtotal = sum((d.subtotal for d in self.details.all()), Decimal('0'))
        self.subtotal = subtotal
        self.tax = subtotal * Decimal('0.15')
        self.total = self.subtotal + self.tax
        self.save()

    def delete(self, *args, **kwargs):
        for detail in self.details.all():
            Product.objects.filter(pk=detail.product_id).update(stock=F('stock') - detail.quantity)
        super().delete(*args, **kwargs)


class PurchaseDetail(models.Model):
    """Purchase line item. Each row is a product acquired."""
    purchase = models.ForeignKey(
        Purchase, on_delete=models.CASCADE, related_name='details'
    )
    product = models.ForeignKey(
        Product, on_delete=models.PROTECT, related_name='purchase_details'
    )
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0.1)])
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f'{self.product.name} x {self.quantity}'

    def save(self, *args, **kwargs):
        self.subtotal = self.quantity * self.unit_cost
        super().save(*args, **kwargs)
        self.purchase.recalculate()
        Product.objects.filter(pk=self.product_id).update(stock=F('stock') + self.quantity)
