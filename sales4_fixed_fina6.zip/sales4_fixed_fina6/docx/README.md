# Sistema de Ventas

Aplicación web desarrollada en **Django** para la gestión de ventas e inventario de una empresa: marcas, grupos de producto, proveedores, productos, clientes, facturación y compras. Incluye validaciones específicas para Ecuador (cédula/RUC, celular) y exportación de listados a **PDF** y **Excel**.

## Tabla de contenidos

- [Características](#características)
- [Tecnologías](#tecnologías)
- [Estructura del proyecto](#estructura-del-proyecto)
- [Modelo de datos](#modelo-de-datos)
- [Instalación](#instalación)
- [Uso](#uso)
- [Módulos y rutas](#módulos-y-rutas)
- [Exportación a PDF y Excel](#exportación-a-pdf-y-excel)
- [Validaciones para Ecuador](#validaciones-para-ecuador)
- [Capturas de pantalla](#capturas-de-pantalla)
- [Documentación del ORM](#documentación-del-orm)

## Características

- **Marcas**: catálogo de marcas de producto (activar/desactivar, CRUD completo).
- **Grupos de producto**: categorías para clasificar productos (ej. Lavadoras, Televisores, Celulares).
- **Proveedores**: catálogo de proveedores con contacto, correo y teléfono.
- **Productos**: inventario con marca, grupo, precio, stock, foto, valor en inventario y proveedores asociados (relación muchos a muchos).
- **Clientes**: registro de clientes con validación de cédula/RUC ecuatoriana.
- **Facturas**: generación de facturas con detalle, subtotal, IVA (15%) y total; el stock del producto se descuenta automáticamente al facturar.
- **Compras**: registro de compras a proveedores con número de factura del proveedor, subtotal, IVA y total; el stock del producto se incrementa automáticamente al registrar la compra.
- **Autenticación**: inicio de sesión, registro y manejo de cuentas con `django.contrib.auth`.
- **Exportación**: cada listado puede exportarse a PDF o a Excel respetando los filtros activos.
- **Filtros**: búsqueda y filtros en los listados principales.

## Tecnologías

| Componente   | Versión / Librería |
|--------------|---------------------|
| Backend      | Django 6.0.6 |
| Base de datos| SQLite (`dbventas.sqlite3`) |
| PDF          | ReportLab |
| Excel        | openpyxl |
| Imágenes     | Pillow |
| Idioma       | Español (Ecuador) — `LANGUAGE_CODE = 'es-ec'` |

## Estructura del proyecto

```
sales4_fixed_fina6/
├── config/                # Configuración del proyecto (settings, urls, asgi, wsgi)
├── billing/                # App principal: marcas, grupos, proveedores, productos,
│                           # clientes y facturas
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── forms.py
│   └── templates/
├── purchasing/             # App de compras a proveedores
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   └── templates/
├── shared/                 # Código compartido entre apps
│   ├── validators.py       # Validaciones para cédula/RUC y celular de Ecuador
│   ├── export_mixin.py     # Mixin para exportar listados a PDF / Excel
│   ├── decorators.py
│   └── mixin.py
├── templates/               # Plantillas base y de autenticación
├── media/products/          # Fotos de productos subidas por el usuario
├── dbventas.sqlite3         # Base de datos
├── manage.py
└── requirements.txt
```

## Modelo de datos

```
Brand (Marca) ──┐
ProductGroup ───┼──< Product >── M2M ── Supplier (Proveedor)
                │        │
                │        └──< InvoiceDetail >── Invoice ── FK ── Customer
                │                                                   │
                │                                              CustomerProfile (1-1)
                │
                └──< PurchaseDetail >── Purchase ── FK ── Supplier
```

- **Brand**, **ProductGroup**, **Supplier**: catálogos base.
- **Product**: pertenece a una `Brand` y a un `ProductGroup` (`ForeignKey`), y puede tener varios `Supplier` (`ManyToMany`).
- **Customer**: tiene un `CustomerProfile` asociado (`OneToOne`) con tipo de contribuyente, forma de pago y cupo de crédito.
- **Invoice / InvoiceDetail**: factura de venta a un cliente; al guardar un detalle se recalcula el total de la factura y se descuenta el stock del producto.
- **Purchase / PurchaseDetail**: compra a un proveedor; al guardar un detalle se recalcula el total de la compra y se incrementa el stock del producto.

## Instalación

1. Clonar o copiar el proyecto y entrar a la carpeta:

   ```bash
   cd sales4_fixed_fina6
   ```

2. Crear y activar un entorno virtual:

   ```bash
   python -m venv .venv
   # Windows
   .venv\Scripts\activate
   # Linux / macOS
   source .venv/bin/activate
   ```

3. Instalar dependencias:

   ```bash
   pip install -r requirements.txt
   ```

4. Aplicar migraciones:

   ```bash
   python manage.py migrate
   ```

5. Crear un superusuario (para acceder al panel de administración):

   ```bash
   python manage.py createsuperuser
   ```

6. Levantar el servidor de desarrollo:

   ```bash
   python manage.py runserver
   ```

7. Abrir en el navegador: [http://127.0.0.1:8000/](http://127.0.0.1:8000/)

## Uso

1. Iniciar sesión con el usuario creado (`/accounts/login/`).
2. Registrar primero los catálogos base: **Marcas**, **Grupos de Producto** y **Proveedores**.
3. Crear **Productos**, asociándolos a una marca, un grupo y uno o varios proveedores.
4. Registrar **Clientes**.
5. Generar **Facturas** seleccionando cliente y productos; el sistema calcula automáticamente subtotal, IVA (15%) y total, y descuenta el stock.
6. Registrar **Compras** a un proveedor para reabastecer el stock de los productos.

## Módulos y rutas

| Módulo | Ruta base | Acciones disponibles |
|--------|-----------|------------------------|
| Marcas | `/brands/` | Listar, crear, editar, eliminar |
| Grupos de producto | `/groups/` | Listar, crear, editar, eliminar |
| Proveedores | `/suppliers/` | Listar, crear, editar, eliminar |
| Productos | `/products/` | Listar, crear, editar, eliminar |
| Clientes | `/customers/` | Listar, crear, editar, eliminar |
| Facturas | `/invoices/` | Listar, crear, ver detalle, eliminar |
| Compras | `/purchases/` | Listar, crear, ver detalle, eliminar |
| Administración | `/admin/` | Panel de administración de Django |
| Cuentas | `/accounts/` | Login, logout, registro |

> Al eliminar una factura o una compra, el stock de los productos involucrados se restaura/ajusta automáticamente. Un proveedor no puede eliminarse si tiene productos asociados (se lanza `ProtectedError`).

## Exportación a PDF y Excel

Todos los listados (Marcas, Grupos, Proveedores, Productos, Clientes, Facturas, Compras) incluyen botones **PDF** y **Excel** que exportan exactamente lo que se está visualizando, respetando los filtros aplicados. Esto se implementa mediante un mixin reutilizable (`ListExportMixin`) que detecta el parámetro `?export=pdf` o `?export=excel` en la URL y genera el archivo con **ReportLab** (PDF) u **openpyxl** (Excel).

## Validaciones para Ecuador

El proyecto incluye validadores personalizados en `shared/validators.py`:

- Validación de **cédula y RUC ecuatoriano** (`validate_cedula_ec`).
- Validación y normalización de **números celulares de Ecuador** (`validate_ecuador_cellphone`, `normalize_ecuador_cellphone`).
- Validación de nombres y apellidos (sin números).

## Capturas de pantalla

| Módulo | Vista |
|--------|-------|
| Marcas | Listado con conteo, filtros y exportación |
| Grupos de Producto | Listado con conteo, filtros y exportación |
| Proveedores | Listado con datos de contacto |
| Productos | Listado con foto, marca, grupo, precio, stock, valor y proveedores |
| Clientes | Listado con cédula, nombre y datos de contacto |
| Facturas | Listado con subtotal, IVA y total |
| Compras | Listado con número de factura del proveedor, subtotal, IVA y total |

> Coloca tus capturas de pantalla dentro de una carpeta `docs/screenshots/` y referencia cada imagen aquí, por ejemplo:
> `![Listado de Productos](docs/screenshots/productos.png)`

## Documentación del ORM

Para una referencia detallada de las operaciones CRUD, relaciones y agregaciones realizadas con el ORM de Django sobre este proyecto (con sentencia y salida de cada consulta), ver el documento:

📄 `ORM_Sistema_Ventas.docx`
