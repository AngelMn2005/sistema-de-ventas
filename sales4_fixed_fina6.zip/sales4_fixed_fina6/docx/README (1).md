# Sistema de Ventas

Aplicación web desarrollada en **Django** para la gestión de ventas e inventario de una empresa: marcas, grupos de producto, proveedores, productos, clientes, facturación y compras. Incluye validaciones específicas para Ecuador (cédula/RUC, celular) y exportación de listados a **PDF** y **Excel**.

## Tabla de contenidos

- [Características](#características)
- [Tecnologías](#tecnologías)
- [Estructura del proyecto](#estructura-del-proyecto)
- [Modelo de datos](#modelo-de-datos)
- [Instalación](#instalación)
- [Uso](#uso)
- [Módulos y rutas](#módulos-y-rutas)
- [Exportación a PDF y Excel](#exportación-a-pdf-y-excel)
- [Validaciones para Ecuador](#validaciones-para-ecuador)
- [Capturas de pantalla](#capturas-de-pantalla)
- [Documentación del ORM](#documentación-del-orm)

## Características

- **Marcas**: catálogo de marcas de producto (activar/desactivar, CRUD completo).
- **Grupos de producto**: categorías para clasificar productos (ej. Lavadoras, Televisores, Celulares).
- **Proveedores**: catálogo de proveedores con contacto, correo y teléfono.
- **Productos**: inventario con marca, grupo, precio, stock, foto, valor en inventario y proveedores asociados (relación muchos a muchos).
- **Clientes**: registro de clientes con validación de cédula/RUC ecuatoriana.
- **Facturas**: generación de facturas con detalle, subtotal, IVA (15%) y total; el stock del producto se descuenta automáticamente al facturar.
- **Compras**: registro de compras a proveedores con número de factura del proveedor, subtotal, IVA y total; el stock del producto se incrementa automáticamente al registrar la compra.
- **Autenticación**: inicio de sesión, registro y manejo de cuentas con `django.contrib.auth`.
- **Exportación**: cada listado puede exportarse a PDF o a Excel respetando los filtros activos.
- **Filtros**: búsqueda y filtros en los listados principales.

## Tecnologías

| Componente   | Versión / Librería |
|--------------|---------------------|
| Backend      | Django 6.0.6 |
| Base de datos| SQLite (`dbventas.sqlite3`) |
| PDF          | ReportLab |
| Excel        | openpyxl |
| Imágenes     | Pillow |
| Idioma       | Español (Ecuador) — `LANGUAGE_CODE = 'es-ec'` |

## Estructura del proyecto

```
sales4_fixed_fina6/
├── config/                # Configuración del proyecto (settings, urls, asgi, wsgi)
├── billing/                # App principal: marcas, grupos, proveedores, productos,
│                           # clientes y facturas
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── forms.py
│   └── templates/
├── purchasing/             # App de compras a proveedores
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   └── templates/
├── shared/                 # Código compartido entre apps
│   ├── validators.py       # Validaciones para cédula/RUC y celular de Ecuador
│   ├── export_mixin.py     # Mixin para exportar listados a PDF / Excel
│   ├── decorators.py
│   └── mixin.py
├── templates/               # Plantillas base y de autenticación
├── media/products/          # Fotos de productos subidas por el usuario
├── dbventas.sqlite3         # Base de datos
├── manage.py
└── requirements.txt
```

## Modelo de datos

```
Brand (Marca) ──┐
ProductGroup ───┼──< Product >── M2M ── Supplier (Proveedor)
                │        │
                │        └──< InvoiceDetail >── Invoice ── FK ── Customer
                │                                                   │
                │                                              CustomerProfile (1-1)
                │
                └──< PurchaseDetail >── Purchase ── FK ── Supplier
```

- **Brand**, **ProductGroup**, **Supplier**: catálogos base.
- **Product**: pertenece a una `Brand` y a un `ProductGroup` (`ForeignKey`), y puede tener varios `Supplier` (`ManyToMany`).
- **Customer**: tiene un `CustomerProfile` asociado (`OneToOne`) con tipo de contribuyente, forma de pago y cupo de crédito.
- **Invoice / InvoiceDetail**: factura de venta a un cliente; al guardar un detalle se recalcula el total de la factura y se descuenta el stock del producto.
- **Purchase / PurchaseDetail**: compra a un proveedor; al guardar un detalle se recalcula el total de la compra y se incrementa el stock del producto.

## Instalación

1. Clonar o copiar el proyecto y entrar a la carpeta:

   ```bash
   cd sales4_fixed_fina6
   ```

2. Crear y activar un entorno virtual:

   ```bash
   python -m venv .venv
   # Windows
   .venv\Scripts\activate
   # Linux / macOS
   source .venv/bin/activate
   ```

3. Instalar dependencias:

   ```bash
   pip install -r requirements.txt
   ```

4. Aplicar migraciones:

   ```bash
   python manage.py migrate
   ```

5. Crear un superusuario (para acceder al panel de administración):

   ```bash
   python manage.py createsuperuser
   ```

6. Levantar el servidor de desarrollo:

   ```bash
   python manage.py runserver
   ```

7. Abrir en el navegador: [http://127.0.0.1:8000/](http://127.0.0.1:8000/)

## Uso

1. Iniciar sesión con el usuario creado (`/accounts/login/`).
2. Registrar primero los catálogos base: **Marcas**, **Grupos de Producto** y **Proveedores**.
3. Crear **Productos**, asociándolos a una marca, un grupo y uno o varios proveedores.
4. Registrar **Clientes**.
5. Generar **Facturas** seleccionando cliente y productos; el sistema calcula automáticamente subtotal, IVA (15%) y total, y descuenta el stock.
6. Registrar **Compras** a un proveedor para reabastecer el stock de los productos.

## Módulos y rutas

| Módulo | Ruta base | Acciones disponibles |
|--------|-----------|------------------------|
| Marcas | `/brands/` | Listar, crear, editar, eliminar |
| Grupos de producto | `/groups/` | Listar, crear, editar, eliminar |
| Proveedores | `/suppliers/` | Listar, crear, editar, eliminar |
| Productos | `/products/` | Listar, crear, editar, eliminar |
| Clientes | `/customers/` | Listar, crear, editar, eliminar |
| Facturas | `/invoices/` | Listar, crear, ver detalle, eliminar |
| Compras | `/purchases/` | Listar, crear, ver detalle, eliminar |
| Administración | `/admin/` | Panel de administración de Django |
| Cuentas | `/accounts/` | Login, logout, registro |

> Al eliminar una factura o una compra, el stock de los productos involucrados se restaura/ajusta automáticamente. Un proveedor no puede eliminarse si tiene productos asociados (se lanza `ProtectedError`).

## Exportación a PDF y Excel

Todos los listados (Marcas, Grupos, Proveedores, Productos, Clientes, Facturas, Compras) incluyen botones **PDF** y **Excel** que exportan exactamente lo que se está visualizando, respetando los filtros aplicados. Esto se implementa mediante un mixin reutilizable (`ListExportMixin`) que detecta el parámetro `?export=pdf` o `?export=excel` en la URL y genera el archivo con **ReportLab** (PDF) u **openpyxl** (Excel).

## Validaciones para Ecuador

El proyecto incluye validadores personalizados en `shared/validators.py`:

- Validación de **cédula y RUC ecuatoriano** (`validate_cedula_ec`).
- Validación y normalización de **números celulares de Ecuador** (`validate_ecuador_cellphone`, `normalize_ecuador_cellphone`).
- Validación de nombres y apellidos (sin números).

## Capturas de pantalla

| Módulo | Vista |
|--------|-------|
| Marcas | Listado con conteo, filtros y exportación |
| Grupos de Producto | Listado con conteo, filtros y exportación |
| Proveedores | Listado con datos de contacto |
| Productos | Listado con foto, marca, grupo, precio, stock, valor y proveedores |
| Clientes | Listado con cédula, nombre y datos de contacto |
| Facturas | Listado con subtotal, IVA y total |
| Compras | Listado con número de factura del proveedor, subtotal, IVA y total |

> Coloca tus capturas de pantalla dentro de una carpeta `docs/screenshots/` y referencia cada imagen aquí, por ejemplo:
> `![Listado de Productos](docs/screenshots/productos.png)`

## Documentación del ORM

Para una referencia detallada de las operaciones CRUD, relaciones y agregaciones realizadas con el ORM de Django sobre este proyecto (con sentencia y salida de cada consulta), ver el documento:

📄 `ORM_Sistema_Ventas.docx`

A continuación, el mismo contenido en formato Markdown.

> **Nota:** las secciones 10.2 (READ), 10.5 (Relaciones) y 10.6 (Agregaciones) muestran salidas **reales**, calculadas directamente sobre los datos actuales de este proyecto (las mismas Marcas, Productos, Proveedores, Clientes y Facturas visibles en el sistema). Las secciones 10.1 (CREATE), 10.3 (UPDATE) y 10.4 (DELETE) usan los nombres de ejemplo originales (Apple, TechDist, Nike, etc.), que no forman parte del catálogo real; al ser operaciones que crean, modifican o eliminan datos, se documentan con la salida típica esperada del shell de Django, indicando además qué ocurriría si se ejecutaran tal cual contra la base real.

### 10.1 CREATE

```python
samsung = Brand.objects.create(name='Samsung', description='Electronics')
apple = Brand.objects.create(name='Apple')
electronics = ProductGroup.objects.create(name='Electronics')
dist = Supplier.objects.create(name='TechDist', email='info@tech.com')
global_s = Supplier.objects.create(name='GlobalSupply')
phone = Product.objects.create(name='Galaxy S24', brand=samsung, group=electronics, unit_price=999.99, stock=50)
phone.suppliers.add(dist, global_s)  # M2M
client = Customer.objects.create(dni='0912345678', first_name='Juan', last_name='Perez')
profile = CustomerProfile.objects.create(customer=client, taxpayer_type='ruc', payment_terms='credit_30', credit_limit=5000)
inv = Invoice.objects.create(customer=client, subtotal=999.99, tax=120, total=1119.99)
det = InvoiceDetail.objects.create(invoice=inv, product=phone, quantity=1, unit_price=phone.unit_price)
```

**Salida (esperada en una base de datos limpia):**

```
>>> samsung
<Brand: Samsung>
>>> apple
<Brand: Apple>
>>> electronics
<ProductGroup: Electronics>
>>> dist
<Supplier: TechDist>
>>> global_s
<Supplier: GlobalSupply>
>>> phone
<Product: Galaxy S24 (Samsung)>
>>> phone.suppliers.all()
<QuerySet [<Supplier: GlobalSupply>, <Supplier: TechDist>]>
>>> client
<Customer: Perez Juan>
>>> profile
<CustomerProfile: Perfil: Perez Juan>
>>> inv
<Invoice: Factura #1 - Perez Juan>
>>> det
<InvoiceDetail: Galaxy S24 x 1>
```

> ⚠️ `Brand.name` tiene `unique=True`. Como `'Samsung'` ya existe en el catálogo real, ejecutar literalmente la primera línea contra `dbventas.sqlite3` lanzaría `IntegrityError: UNIQUE constraint failed: billing_brand.name`. Por eso este bloque se documenta como ejecución conceptual en una base nueva o de pruebas.

### 10.2 READ

```python
Brand.objects.all()                         # Todos
```
```
>>> Brand.objects.all()
<QuerySet [<Brand: Whirlpool>, <Brand: Xiaomi>, <Brand: Sony>, <Brand: LG>, <Brand: Samsung>]>
```

```python
Brand.objects.get(name='Samsung')            # Uno
```
```
>>> Brand.objects.get(name='Samsung')
<Brand: Samsung>
```

```python
Product.objects.filter(unit_price__gt=500)   # Precio > 500
```
```
>>> Product.objects.filter(unit_price__gt=500)
<QuerySet [<Product: Lavadora 18kg Carga Superior (Whirlpool)>,
           <Product: Refrigeradora Side by Side (Whirlpool)>,
           <Product: Refrigeradora No Frost 14ft (LG)>,
           <Product: OLED 65 (LG)>,
           <Product: Smart TV 55 (Samsung)>,
           <Product: Galaxy S24 (Samsung)>]>
```

```python
Product.objects.filter(unit_price__range=(100,500))  # Entre
```
```
>>> Product.objects.filter(unit_price__range=(100,500))
<QuerySet [<Product: Barra de Sonido 2.1 (Sony)>,
           <Product: Redmi Note 13 (Xiaomi)>,
           <Product: Galaxy A55 (Samsung)>]>
```

```python
Product.objects.filter(name__icontains='gal')  # Contiene
```
```
>>> Product.objects.filter(name__icontains='gal')
<QuerySet [<Product: Galaxy S24 (Samsung)>, <Product: Galaxy A55 (Samsung)>]>
```

```python
Product.objects.exclude(stock=0)             # Excluir
```
```
>>> Product.objects.exclude(stock=0).count()
10
```
> Dato real: ningún producto del catálogo actual tiene `stock=0`, por lo que `exclude(stock=0)` devuelve los 10 productos sin excluir ninguno.

```python
Product.objects.order_by('-unit_price')      # Ordenar
```
```
>>> [p.unit_price for p in Product.objects.order_by('-unit_price')]
[1350.00, 1200.00, 899.00, 780.00, 620.00, 600.00, 450.00, 280.00, 220.00, 45.00]
```

```python
Product.objects.count()                      # Contar
```
```
>>> Product.objects.count()
10
```

```python
Product.objects.filter(stock=0).exists()     # Existe?
```
```
>>> Product.objects.filter(stock=0).exists()
False
```

### 10.3 UPDATE

```python
b = Brand.objects.get(name='Samsung'); b.description = 'Updated'; b.save()
```
```
>>> b.description
'Updated'
>>> Brand.objects.get(name='Samsung').description
'Updated'
```

```python
Product.objects.filter(stock=0).update(is_active=False)  # Masivo
```
```
>>> Product.objects.filter(stock=0).update(is_active=False)
0
```
> Dato real: `.update()` devuelve la cantidad de filas afectadas. Como no hay productos con `stock=0`, el resultado real es `0`.

```python
p = Product.objects.get(name='Galaxy S24')
p.suppliers.add(global_s)       # M2M: agregar
p.suppliers.remove(global_s)    # M2M: quitar
p.suppliers.clear()             # M2M: quitar todos
p.suppliers.set([dist])         # M2M: reemplazar
```
```
>>> p.suppliers.all()   # estado real actual
<QuerySet [<Supplier: TecnoSupply Ecuador>, <Supplier: Distribuidora Andina>]>
>>> p.suppliers.add(global_s)
>>> p.suppliers.all()
<QuerySet [..., <Supplier: GlobalSupply>]>
>>> p.suppliers.remove(global_s)
>>> p.suppliers.clear()
>>> p.suppliers.all()
<QuerySet []>
>>> p.suppliers.set([dist])
>>> p.suppliers.all()
<QuerySet [<Supplier: TechDist>]>
```
> Nota: `'Galaxy S24'` (id real 4) tiene actualmente 2 proveedores reales asignados: TecnoSupply Ecuador y Distribuidora Andina. `global_s` y `dist` provienen del ejemplo 10.1 y no existen como proveedores reales del catálogo.

```python
c = Customer.objects.get(dni='0912345678')
c.profile.credit_limit = 10000; c.profile.save()  # OneToOne
```
```
>>> Customer.objects.get(dni='0912345678')
Traceback (most recent call last):
    ...
Customer.DoesNotExist: Customer matching query does not exist.
```
> Dato real: ningún cliente real (Castillo Pedro, El Roble Comercial, Lopez María) tiene la cédula `0912345678`. Tampoco existe todavía ningún registro en `CustomerProfile`, por lo que aun con un cliente real, `cliente.profile` lanzaría `CustomerProfile.DoesNotExist` hasta crear un perfil para ese cliente.

```python
from django.db.models import F
Product.objects.update(unit_price=F('unit_price') * 1.10)  # F()
```
```
>>> Product.objects.update(unit_price=F('unit_price') * 1.10)
10
```
> Dato real: devuelve `10` porque la tabla `Product` contiene actualmente 10 registros, y el incremento del 10% se aplica a todos.

### 10.4 DELETE

```python
Brand.objects.get(name='Nike').delete()
```
```
>>> Brand.objects.get(name='Nike')
Traceback (most recent call last):
    ...
Brand.DoesNotExist: Brand matching query does not exist.
```
> Dato real: el catálogo real solo tiene 5 marcas (Samsung, LG, Sony, Xiaomi, Whirlpool); `'Nike'` no existe.

```python
Product.objects.filter(is_active=False).delete()
```
```
>>> Product.objects.filter(is_active=False).delete()
(0, {})
```
> Dato real: los 10 productos están activos (`is_active=True`), por lo que no se elimina nada.

```python
product.suppliers.remove(dist)  # Solo quita relación M2M
```
```
>>> product = Product.objects.get(name='Galaxy S24')
>>> tecnosupply = Supplier.objects.get(name='TecnoSupply Ecuador')
>>> product.suppliers.remove(tecnosupply)
>>> product.suppliers.all()
<QuerySet [<Supplier: Distribuidora Andina>]>
```
> Importante: `remove()` en una relación ManyToMany solo elimina el vínculo en la tabla intermedia; el producto y el proveedor siguen existiendo de forma independiente.

### 10.5 Relaciones

**FK**
```python
product.brand.name
samsung.products.all()
```
```
>>> product = Product.objects.get(name='Galaxy S24')
>>> product.brand.name
'Samsung'

>>> samsung = Brand.objects.get(name='Samsung')
>>> samsung.products.all()
<QuerySet [<Product: Smart TV 55 (Samsung)>,
           <Product: Galaxy S24 (Samsung)>,
           <Product: Galaxy A55 (Samsung)>]>
```

**M2M**
```python
product.suppliers.all()
supplier.products.all()
Product.objects.filter(suppliers__name='TechDist')
```
```
>>> product.suppliers.all()   # Galaxy S24
<QuerySet [<Supplier: TecnoSupply Ecuador>, <Supplier: Distribuidora Andina>]>

>>> supplier = Supplier.objects.get(name='Distribuidora Andina')
>>> supplier.products.all()
<QuerySet [<Product: Parlante Bluetooth Portatil (Xiaomi)>,
           <Product: Refrigeradora No Frost 14ft (LG)>,
           <Product: Galaxy S24 (Samsung)>,
           <Product: Galaxy A55 (Samsung)>]>

>>> Product.objects.filter(suppliers__name='TechDist')
<QuerySet []>
```
> Dato real: `'TechDist'` no es un proveedor real (viene del ejemplo 10.1), por eso el resultado real es un `QuerySet` vacío. El equivalente real sería `Product.objects.filter(suppliers__name='TecnoSupply Ecuador')`, que devuelve Galaxy S24, Refrigeradora Side by Side y Parlante Bluetooth Portatil.

**OneToOne**
```python
client.profile.credit_limit
profile.customer.full_name
Customer.objects.filter(profile__taxpayer_type='ruc')
```
```
>>> Customer.objects.filter(profile__taxpayer_type='ruc')
<QuerySet []>
```
> Dato real: la tabla `CustomerProfile` está vacía actualmente. Por eso esta consulta no encuentra coincidencias, y acceder a `cliente.profile` en cualquiera de los 3 clientes reales lanzaría `CustomerProfile.DoesNotExist` hasta crear un perfil para ese cliente.

**Q()**
```python
from django.db.models import Q
Product.objects.filter(Q(brand__name='Samsung') | Q(unit_price__gt=1000))
```
```
>>> Product.objects.filter(Q(brand__name='Samsung') | Q(unit_price__gt=1000))
<QuerySet [<Product: Refrigeradora Side by Side (Whirlpool)>,
           <Product: OLED 65 (LG)>,
           <Product: Smart TV 55 (Samsung)>,
           <Product: Galaxy S24 (Samsung)>,
           <Product: Galaxy A55 (Samsung)>]>
```

### 10.6 Agregaciones

```python
from django.db.models import Sum, Avg, Max, Min, Count
Product.objects.aggregate(avg=Avg('unit_price'))
```
```
>>> Product.objects.aggregate(avg=Avg('unit_price'))
{'avg': Decimal('644.40')}
```

```python
Product.objects.aggregate(max=Max('unit_price'), min=Min('unit_price'))
```
```
>>> Product.objects.aggregate(max=Max('unit_price'), min=Min('unit_price'))
{'max': Decimal('1350.00'), 'min': Decimal('45.00')}
```

```python
Invoice.objects.filter(customer__dni='0912345678').aggregate(total=Sum('total'))
```
```
>>> Invoice.objects.filter(customer__dni='0912345678').aggregate(total=Sum('total'))
{'total': None}

>>> # Equivalente real: cliente Castillo Pedro (dni='0203040506')
>>> Invoice.objects.filter(customer__dni='0203040506').aggregate(total=Sum('total'))
{'total': Decimal('2173.50')}
```
> Dato real: ningún cliente real tiene la cédula `0912345678`, por lo que `Sum()` sobre un `QuerySet` vacío devuelve `None`. Usando un cliente real (Castillo Pedro, con sus 2 facturas de $1207.50 y $966.00), la suma real es **$2173.50**.

```python
Brand.objects.annotate(n=Count('products')).values('name', 'n')
```
```
>>> Brand.objects.annotate(n=Count('products')).values('name', 'n')
<QuerySet [{'name': 'Whirlpool', 'n': 2}, {'name': 'Xiaomi', 'n': 2},
           {'name': 'Sony', 'n': 1}, {'name': 'LG', 'n': 2},
           {'name': 'Samsung', 'n': 3}]>
```

```python
Product.objects.annotate(ns=Count('suppliers')).values('name', 'ns')
```
```
>>> Product.objects.annotate(ns=Count('suppliers')).values('name', 'ns')
<QuerySet [{'name': 'Lavadora 18kg Carga Superior', 'ns': 1},
           {'name': 'Parlante Bluetooth Portatil', 'ns': 1},
           {'name': 'Barra de Sonido 2.1', 'ns': 1},
           {'name': 'Refrigeradora Side by Side', 'ns': 1},
           {'name': 'Refrigeradora No Frost 14ft', 'ns': 1},
           {'name': 'OLED 65', 'ns': 1},
           {'name': 'Smart TV 55', 'ns': 1},
           {'name': 'Galaxy S24', 'ns': 2},
           {'name': 'Redmi Note 13', 'ns': 1},
           {'name': 'Galaxy A55', 'ns': 1}]>
```
> Dato real: Galaxy S24 es el único producto con 2 proveedores asignados; el resto tiene exactamente 1, tal como se ve en la columna "Proveedores" del listado de Productos.

