import re
from django.core.exceptions import ValidationError

def validate_cedula_ec(value):

    if not value.isdigit():
        raise ValidationError(
            'La cédula o RUC solo debe contener números.'
        )

    if len(value) not in (10, 13):
        raise ValidationError(
            'La cédula debe tener 10 dígitos o el RUC 13.'
        )

    provincia = int(value[:2])

    if provincia < 1 or provincia > 24:
        raise ValidationError(
            'Código de provincia inválido.'
        )

    tercer_digito = int(value[2])

    if tercer_digito >= 6:
        raise ValidationError(
            'El tercer dígito debe ser menor a 6.'
        )

    coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2]
    total = 0

    for i in range(9):
        valor = int(value[i]) * coeficientes[i]

        if valor > 9:
            valor -= 9

        total += valor

    digito_verificador = 10 - (total % 10)

    if digito_verificador == 10:
        digito_verificador = 0

    if digito_verificador != int(value[9]):
        raise ValidationError(
            'Cédula o RUC inválido.'
        )

    # Si es RUC debe terminar en 001
    if len(value) == 13:
        if value[10:] != '001':
            raise ValidationError(
                'RUC inválido. Debe terminar en 001.'
            )

    return value


def normalize_ecuador_cellphone(value):
    value = (value or '').strip()
    if not value:
        return value

    digits = value.replace(' ', '').replace('-', '')
    if digits.startswith('+'):
        digits = digits[1:]

    if digits.startswith('5939') and len(digits) == 12:
        return f'+{digits}'

    if digits.startswith('09') and len(digits) == 10:
        return f'+593{digits[1:]}'

    if digits.startswith('9') and len(digits) == 9:
        return f'+593{digits}'

    return value


def validate_ecuador_cellphone(value):
    value = (value or '').strip()
    if not value:
        return value

    normalized = normalize_ecuador_cellphone(value)
    digits = normalized[1:] if normalized.startswith('+') else normalized

    if not digits.isdigit():
        raise ValidationError(
            'El celular solo debe contener numeros.'
        )

    if not (digits.startswith('5939') and len(digits) == 12):
        raise ValidationError(
            'Ingrese un celular ecuatoriano valido. Ej: 0987654321 o +593987654321.'
        )

    return value

# Validar nombres (solo letras y espacios)
def validate_name(value):
    value = (value or '').strip()

    if not value:
        raise ValidationError('Este campo es obligatorio.')

    if not re.fullmatch(r"[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s'-]+", value):
        raise ValidationError(
            'Solo se permiten letras y espacios.'
        )

# Validar que no tenga números
def validate_no_numbers(value):
    if any(char.isdigit() for char in value):
        raise ValidationError('No se permiten números.')
    

# Validar apellidos (solo letras y espacios)
def validate_last_name(value):
    value = (value or '').strip()

    if not value:
        raise ValidationError('El apellido es obligatorio.')

    # Solo letras y espacios (incluye tildes y ñ)
    if not re.fullmatch(r"[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s'-]+", value):
        raise ValidationError(
            'El apellido solo puede contener letras. '
            'No se permiten números ni caracteres especiales.'
        )