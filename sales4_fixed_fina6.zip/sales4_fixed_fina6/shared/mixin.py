from django.contrib import messages
from django.shortcuts import redirect
from django.db.models import ProtectedError


class ListContextMixin:
    """Contexto comun para las pantallas de listado."""
    page_title = ''

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = self.page_title
        context['total_count'] = self.object_list.count()
        context['q'] = self.request.GET
        return context


class QueryFilterMixin:
    """Helpers pequenos para aplicar filtros GET repetidos."""
    simple_filters = {}
    range_filters = {}
    status_field = 'is_active'

    def apply_simple_filters(self, qs):
        for param, lookup in self.simple_filters.items():
            value = self.request.GET.get(param, '').strip()
            if value:
                qs = qs.filter(**{lookup: value})
        return qs

    def apply_range_filters(self, qs):
        for param, lookup in self.range_filters.items():
            value = self.request.GET.get(param, '').strip()
            if value:
                qs = qs.filter(**{lookup: value})
        return qs

    def apply_status_filter(self, qs):
        status = self.request.GET.get('status', '').strip()
        if status == 'active':
            return qs.filter(**{self.status_field: True})
        if status == 'inactive':
            return qs.filter(**{self.status_field: False})
        return qs

    def apply_list_filters(self, qs):
        qs = self.apply_simple_filters(qs)
        qs = self.apply_range_filters(qs)
        return self.apply_status_filter(qs)


class StaffRequiredMixin:
    staff_error_message = 'Solo usuarios staff pueden eliminar registros.'

    def dispatch(self, request, *args, **kwargs):

        if not request.user.is_staff:
            messages.error(request, self.staff_error_message)
            return redirect(self.staff_redirect_url)

        return super().dispatch(request, *args, **kwargs)


class ProtectedDeleteMixin:
    """
    Evita que una eliminación con relaciones protegidas (on_delete=PROTECT)
    rompa la página con un ProtectedError. En su lugar, muestra un mensaje
    de error y redirige de vuelta al listado.
    """
    protected_error_message = 'No se puede eliminar "{obj}" porque tiene registros relacionados.'

    def form_valid(self, form):
        try:
            return super().form_valid(form)
        except ProtectedError:
            messages.error(
                self.request,
                self.protected_error_message.format(obj=self.object)
            )
            return redirect(self.success_url)
