"""
ListExportMixin — Mixin genérico para exportar listados a PDF y Excel.

USO en cualquier ListView:
    1. Heredar de ListExportMixin antes de ListView
    2. Definir export_fields = [('Titulo', 'campo' | callable), ...]
    3. Definir export_title y export_filename

El mixin detecta ?export=pdf o ?export=excel en la URL
y genera el archivo respetando los filtros activos de get_queryset().

Las funciones export_queryset_excel() y export_queryset_pdf() están
disponibles también para usarlas directamente en vistas basadas en
función (FBV), como brand_list, sin tener que pasar por una clase.
"""

from decimal import Decimal
from datetime import date, datetime

from django.http import HttpResponse


def _resolve(obj, accessor):
    """Obtiene el valor de un campo según el accesor."""
    if callable(accessor):
        return accessor(obj)
    value = obj
    for part in accessor.split('.'):
        value = getattr(value, part)
        if callable(value):
            value = value()
    return value


def _as_excel_value(value):
    """Convierte el valor a un tipo que openpyxl maneje bien."""
    if value is None:
        return ''
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d %H:%M')
    if isinstance(value, date):
        return value.strftime('%Y-%m-%d')
    if isinstance(value, (int, float, str)):
        return value
    # ManyToMany manager u otro iterable
    if hasattr(value, 'all'):
        return ', '.join(str(x) for x in value.all())
    return str(value)


def export_queryset_excel(qs, fields, title, filename):
    """Exporta un queryset a un archivo .xlsx, respetando filtros aplicados."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = title[:31] or 'Sheet1'

    # Encabezados con estilo
    headers = [label for label, _ in fields]
    ws.append(headers)
    header_fill = PatternFill('solid', fgColor='0D6EFD')
    header_font = Font(bold=True, color='FFFFFF')
    for col, _ in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')

    # Filas de datos
    for obj in qs:
        row = []
        for _, acc in fields:
            value = _resolve(obj, acc)
            row.append(_as_excel_value(value))
        ws.append(row)

    # Ancho de columnas aproximado al contenido
    for col, header in enumerate(headers, start=1):
        max_len = len(str(header))
        for row in range(2, ws.max_row + 1):
            val = ws.cell(row=row, column=col).value
            max_len = max(max_len, len(str(val)) if val is not None else 0)
        width = min(max(max_len + 4, len(str(header)) + 8), 50)
        ws.column_dimensions[ws.cell(row=1, column=col).column_letter].width = width

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="{filename}.xlsx"'
    wb.save(response)
    return response


def export_queryset_pdf(qs, fields, title, filename):
    """Exporta un queryset a un archivo .pdf, respetando filtros aplicados."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}.pdf"'

    doc = SimpleDocTemplate(
        response, pagesize=landscape(A4),
        leftMargin=1.5 * cm, rightMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm,
    )
    styles = getSampleStyleSheet()
    elements = [Paragraph(title, styles['Title']), Spacer(1, 12)]

    # Datos de la tabla (encabezado + filas)
    data = [[label for label, _ in fields]]
    for obj in qs:
        row = []
        for _, acc in fields:
            value = _resolve(obj, acc)
            value = _as_excel_value(value)
            row.append('' if value is None else str(value))
        data.append(row)

    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0D6EFD')),
        ('TEXTCOLOR',  (0, 0), (-1, 0), colors.white),
        ('FONTNAME',   (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE',   (0, 0), (-1, -1), 9),
        ('ALIGN',      (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN',     (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#DEE2E6')]),
        ('GRID',       (0, 0), (-1, -1), 0.5, colors.HexColor('#DEE2E6')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 12))
    elements.append(Paragraph(f'Total records: {len(data) - 1}', styles['Normal']))

    doc.build(elements)
    return response


class ListExportMixin:
    export_fields = []          # list[tuple[str, str|callable]]
    export_title = 'Listado'
    export_filename = 'export'

    # --- API que se puede sobreescribir ---
    def get_export_queryset(self):
        """Queryset a exportar. Por defecto el mismo del listado (ya filtrado)."""
        return self.get_queryset()

    def get_export_fields(self):
        return self.export_fields

    # --- Punto de entrada: detecta ?export=pdf|excel ---
    def get(self, request, *args, **kwargs):
        export = request.GET.get('export')
        if export == 'excel':
            return self.export_excel()
        if export == 'pdf':
            return self.export_pdf()
        return super().get(request, *args, **kwargs)

    # --- Exportar a Excel ---
    def export_excel(self):
        return export_queryset_excel(
            self.get_export_queryset(), self.get_export_fields(),
            self.export_title, self.export_filename,
        )

    # --- Exportar a PDF ---
    def export_pdf(self):
        return export_queryset_pdf(
            self.get_export_queryset(), self.get_export_fields(),
            self.export_title, self.export_filename,
        )
