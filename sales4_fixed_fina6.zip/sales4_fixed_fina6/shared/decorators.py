import logging
from functools import wraps

from django.utils import timezone


logger = logging.getLogger('audit')


def audit_action(action_name):
    """Print a simple audit message before and after a view action."""
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            user = request.user.username if request.user.is_authenticated else 'Anonymous'
            ip = request.META.get('REMOTE_ADDR', 'unknown')
            method = request.method
            path = request.path
            timestamp = timezone.now().strftime('%Y-%m-%d %H:%M:%S')

            print(
                f'[AUDIT] {timestamp} | User: {user} | '
                f'Action: {action_name} | Method: {method} | '
                f'Path: {path} | IP: {ip}'
            )

            response = view_func(request, *args, **kwargs)

            if method == 'POST':
                print(f'[AUDIT] {timestamp} | COMPLETED: {action_name} by {user}')

            return response

        return wrapper

    return decorator
